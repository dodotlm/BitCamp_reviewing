package chap99_homework.homework13;

@FunctionalInterface
public interface StringBuilderUtils {
	public StringBuilder combineStrBuilder(
			StringBuilder sb1, StringBuilder sb2);
}
