package chap99_homework.homework13;

@FunctionalInterface
public interface MaxMinMid {
	public int maxOrMinOrMid(int[] arr);
}
