package Chap04_controlstatement;

import java.util.Scanner;

public class _09_Break02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 2. 사용자가 입력한 숫자 단까지 구구단을 출력하는 프로그램을 작성하시오. 0을 입력하면 종료할 수 있도록 합니다.
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			
			System.out.print("숫자를 입력하세요(0을 누르면 종료) : ");
			int userNum = sc.nextInt();
			
			if (userNum == 0)
			{
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			
			for(int i =1; i <=userNum; i++)
			{
				for(int k =1; k <= 3; k++)
				{
					System.out.println(i + " X " + k + " = " + (k*i));
				}
				System.out.println();
			}
			
			
			
		}
		
		sc.close();
		

	}

}
