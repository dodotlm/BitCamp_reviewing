package Chap04_controlstatement;

import java.util.Scanner;

public class _11_Continue02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// 3. 사용자가 입력한 숫자 단까지 구구단을 출력하는 프로그램을 작성하세요. 0을 입력하면 종료.
		// 2~9까지의 숫자만 입력할 수 있도록 한다. 다른 숫자를 입력하면 continue를 이용해서 다시 숫자를 입력하게 하도록 한다.
		
		Scanner sc = new Scanner(System.in);
		
		
		
		while(true)
		{
			System.out.print("숫자를 입력하세요 : ");
			int num1 = sc.nextInt();
			
			if (num1 >= 2 && num1 <= 9) {
				for(int i =1; i <=num1; i++) {
					for(int k=1; k <=9; k++) {
						System.out.println(i + "X" + k + " = " + i*k);
					}
					System.out.println();
				}
			}
			else if(num1 == 0) {
				break;
			}
			else {
				System.out.println("2에서 9까지 숫자를 입력해주세요!");
				continue;
			}
			
			
		}
		
		sc.close();

	}

}
