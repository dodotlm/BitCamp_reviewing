package Chap04_controlstatement;

import java.util.Scanner;

public class _08_Break01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		//사용자가 0을 입력하기 전까지 입력한 모든 정수의 합을 출력
		
		int sum = 0;
		
		while(true) {
			
			System.out.print("숫자를 입력하세요(0 입력 시 종료) : ");
			
			int userNum = sc.nextInt();
			
			if (userNum == 0) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			
			System.out.println("입력한 숫자 : " + userNum);
			sum = sum + userNum;
			
			
		}
		
		System.out.println("지금가지 입력한 숫자들의 합" + sum);
		sc.close();
		
		

	}

}
