package Chap04_controlstatement;

public class _07_DuplicatedFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 중복 for문
		
		for(int i = 0; i < 5; i++)
		{
			for(int j = 0; j < 5; j++)
			{
				System.out.print("    i : " + i + "  j : " + j);
			}
			
			System.out.println("       i값 증가!\n");
		}
		
		
		
		// 2. 2~9단까지 구구단 출력
		
		for(int k=2; k<=9; k++)
		{
			System.out.print(k + "단 : ");
			for(int l=1; l<=9; l++)
			{
				System.out.print(k + " X " + l + " = " + (k*l) + "  ");
			}
			System.out.println("\n");
		}
		
		
		// 3. 별이 5개씩 다섯 줄이 찍히도록
		
		for(int num1 = 1; num1 <=5; num1++)
		{
			for(int num2 = 1; num2 <=5; num2++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		System.out.println("===============================\n");
		
		// 4. AB + BA = 99를 만족하는 AB를 모두 풀력하는 중첩 for문
		
		for(int num3 = 0; num3 <= 9; num3++)
		{
			for(int num4 = 0; num4 <= 9; num4++)
			{
				if((num3*10+num4) + (num4*10+num3) == 99)
				{
					System.out.println((num3*10+num4) + "+" + (num4*10+num3) + " = " + 99);
				}
			}
		}
		
		
		
		
		

	}

}
