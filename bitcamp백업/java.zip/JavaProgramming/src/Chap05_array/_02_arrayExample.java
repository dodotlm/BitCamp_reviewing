package Chap05_array;

public class _02_arrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 10개의 정수를 저장하는 배열을 생성하고 3의 배수만 10개 저장하세요.
		
		int[] intArr1 = new int[10];
		
		int i = 0;
		
		while(i<intArr1.length) {
			
			intArr1[i] = (i+1) * 3;
			
			System.out.println(intArr1[i]);
			
			++i;
		}
			
		
		
		
		

	}
}
