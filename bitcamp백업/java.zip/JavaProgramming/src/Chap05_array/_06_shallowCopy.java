package Chap05_array;

public class _06_shallowCopy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr = {1,2,3,4,5};
		
		int[] copyArr = arr;
		
		System.out.println("=================");
		System.out.println(arr[0]);
		System.out.println(copyArr[0]);
		System.out.println(arr);
		System.out.println(copyArr);
		System.out.println("=================");
		
		copyArr[0] = 3;
		System.out.println("=================");
		System.out.println(arr[0]);
		System.out.println(copyArr[0]);
		System.out.println(arr);
		System.out.println(copyArr);
		System.out.println("=================");
		
		int[] copyArr2 = arr.clone();
		
		System.out.println("=================");
		System.out.println(arr[0]);
		System.out.println(copyArr2[0]);
		System.out.println(arr);
		System.out.println(copyArr2);
		System.out.println("=================");
		
	}

}
