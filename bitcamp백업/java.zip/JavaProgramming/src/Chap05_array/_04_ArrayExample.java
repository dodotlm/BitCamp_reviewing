package Chap05_array;

import java.util.Random;

public class _04_ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// 1. 자바에서 랜덤 값 생성방법 1: Random 클래스 사용
		// Random.nextLnt(바운드): 0 ~ 바운드-1 까지의 랜덤한 값 생성
		
		
		
		Random random = new Random();
		/*
		int randomVal1 = random.nextInt(3);
		System.out.println(randomVal1);
		
		int randomVal2 = random.nextInt(3)+1;
		System.out.println(randomVal2);
		
		// 2. 자바에서 랜덤 값 생성방법 2: Math 클래스의 Random() 메소드 사용
		// 0<= Math.random() < 1의 실수 값을 랜덤으로 리턴
		// 0 * 10 <= Math.random() *10 < 1*10
		// (int)0 * 10 <= (int)Math.random() *10 < (int)1*10
		// (int)0 * 10 + 1 <= (int)Math.random() *10 + 1 < (int)1*10 + 1
		
		randomVal1 = (int)(Math.random() * 10)+1;
		System.out.println(randomVal1);
		
		*/
		
		
		// 3. 정수 10개를 저장하는 배열을 생성하고 1부터 100까지의 랜덤값을 10개 저장하고 출력하세요.
		
		int[] intArr = new int[10];
		
		for(int i =0; i <10; i++) {
			int randomVal4 = random.nextInt(100)+1;
			intArr[i] = randomVal4;
			System.out.print(intArr[i] + " ");
		}
		
		
		
		
		
		
		
		

	}

}
