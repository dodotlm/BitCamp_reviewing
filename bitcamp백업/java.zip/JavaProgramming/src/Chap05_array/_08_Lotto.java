package Chap05_array;

import java.util.Random;

public class _08_Lotto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//정수 7개를 저장할 수 있는 배열을 생성
		// 1~45까지의 숫자 중에서 랜덤한 숫자 7개 배열에 저장(중복제거)
		// 로또번호 출력
		//0~5까지의 인덱스는 실제 당첨번호
		// 6번 인덱스는 보너스 번호로 출력
		//이번주 로또 번호는 1,2,3,4,5,6,보너스 번호 : 7
		
		
		
		Random random = new Random();
		
		int[] lottoNum = new int[7];
		
		lottoNum[0] = (random.nextInt(45)+1);
		
		for(int i=1; i<=6; i++) {
			
			lottoNum[i] = (random.nextInt(45)+1);
			if(i>0) {
				for(int j =0; j <i; j++) {
					if(lottoNum[i] == lottoNum[j]) {
						i--; //이게 키포인트네. 안되면 다시 돌아가라 이 이야기 아니야...와 쥑이네
						break;
					}
				}
			}
			
				
		}
		
		
		System.out.print("이번주 로또 번호는 : ");
		for(int i=0; i <=5; i++) {
			System.out.print(lottoNum[i]+" ");
		}
		
		System.out.print(" 보너스 번호 : ");
		System.out.println(lottoNum[6]);

	}

}
