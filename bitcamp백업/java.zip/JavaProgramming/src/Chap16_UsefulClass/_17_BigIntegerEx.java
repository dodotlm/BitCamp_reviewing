package Chap16_UsefulClass;

import java.math.BigInteger;

public class _17_BigIntegerEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 1부터 100까지 곱한 값을 구하세요
		
		BigInteger result1 = BigInteger.valueOf(1);
		BigInteger num1 = BigInteger.valueOf(1);
		for(int i=1; i <= 100; i++) {
			result1 = result1.multiply(num1);
			num1 = num1.add(num1);
		}
		System.out.println(result1);
		long num = factorial(10);
		System.out.println(num);
		
		
		
		for(int i =1; i<=100; i++) {
			System.out.println(i+"!은 : "+factorialBigInteger(BigInteger.valueOf(i)));
		}
		
	}
	
	public static long factorial(long num) {
		if(num == 0) {
			return 1;
		}
		else {
			// 재귀 메소드!
			return num * factorial(num-1);
		}
	}
	
	public static BigInteger factorialBigInteger(BigInteger bigInt) {
		BigInteger temp = BigInteger.valueOf(1);
		if(bigInt.intValue() == 0) {
			return temp;
		}
		else {
			// 재귀 메소드!
			return bigInt.multiply(factorialBigInteger(bigInt.subtract(temp)));
		}
	}
}
