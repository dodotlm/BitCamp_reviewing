package Chap16_UsefulClass;

import java.util.Scanner;

public class _05_StringEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 사용자가 문자열 두 개 입력하여 str1, str2에 저장
		// str1이 str2를 포함하면 str1에 있는 str2를 빈칸으로 출력
		// str1이 str2를 포함하지 않으면 str1에서 str2를 찾을 수 없습니다.출력
		
		
		Scanner sc = new Scanner(System.in);
		System.out.print("문자열을 입력하세요 : ");
		String str1 = sc.nextLine();
		System.out.print("앞선 입력한 문장 안에 포함되어 있는 문자열 입력 : ");
		String str2 = sc.nextLine();
		
		if(str1.contains(str2)) {
			String str3 = str1.replaceAll(str2," ");
			System.out.println(str3);
		}
		else {
			System.out.println("str1에서 str2를 찾을 수 없습니다");
		}

	}

	

}
