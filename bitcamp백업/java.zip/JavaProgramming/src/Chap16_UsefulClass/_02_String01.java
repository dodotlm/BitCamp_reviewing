package Chap16_UsefulClass;

public class _02_String01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. String 객체 생성
		
		String str1 = "bitcamp";
		String str2 = new String("bitcamp");
		String str3 = new String(new char[] {'b','i'});
		String str4 = "bitcamp";
		
		
		// 2. String은 불변성을 가지고 있어서 값을 변경했을 때
		// 메모리에 저장된 문자열 값을 직접 변경하지 않고
		// 새로운 문자열을 메모리에 새로 저장한다.
		
		str4 = "naver";
		System.out.println(str4.hashCode());
		str4 = "cloud";
		System.out.println(str4.hashCode());
		
		
		// 3. == 같은 주소에 있는 개체를 바라보고 있는지 확인
		if(str1 == str2) {
			System.out.println("같은 객체입니다");
		}else {
			System.out.println("다른 객체입니다");

		}
		
		
		// 4. 같은 문자열인지를 비교할 때는 equals 메소드 사용
		if(str1.equals(str2)) {
			System.out.println("같은 객체입니다");
		}else {
			System.out.println("다른 객체입니다");

		}
		
		// equalsIgnorecase : 대소문자 구분없이 문자열값 비교
		String str6 = "abcde";
		String str7 = "ABCDE";
		
		if(str6.compareTo(str7) == 0) {
			System.out.println("같습니다");
		}else {
			System.out.println("No");
		}
		
		if(str6.equalsIgnoreCase(str7)) {
			System.out.println("같습니다");
		}else {
			System.out.println("No");
		}
		
		
		
		
		
		// 5. 문자열이 같은지 비교해주는 메소드
		// 같으면 0 다르면 1이나 -1을 리턴한다.
		
		System.out.println(str1.compareTo(str2));
		System.out.println(str1.compareTo(str3));
		
		
		// 6. concat: 문자열을 합쳐서 새로운 문자열을 리턴하는 메소드
		String str5 = "cloud";
		str1 = "naver";
		
		String newStr = str1.concat(str5);
		System.out.println(newStr);
		
		
		
		
		

	}

}
