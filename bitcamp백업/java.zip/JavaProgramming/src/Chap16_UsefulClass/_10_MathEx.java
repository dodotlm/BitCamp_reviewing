package Chap16_UsefulClass;

import java.util.Scanner;

public class _10_MathEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 사용자가 5개의 정수를 입력하고 배열에 저장
		// 배열에 저장된 정수 5개 중 최소값을 구하세요
		// Math.max와 Math.min을 이용하세요
		
		int[] intArr = new int[5];
		
		Scanner sc = new Scanner(System.in);
		
		for(int i =0;i<intArr.length;i++) {
			System.out.print("숫자를 입력하세요 : ");
			intArr[i] = sc.nextInt();
		}
		
		int max = intArr[0];
		int min = intArr[0];
		
		for(int i=0; i<intArr.length-1; i++) {
			if(Math.max(max, intArr[i+1]) == intArr[i+1]) {
				max = intArr[i+1];
			}
		}
		
		for(int i=0; i<intArr.length-1; i++) {
			if(Math.min(min, intArr[i+1]) == intArr[i+1]) {
				min = intArr[i+1];
			}
		}
		
		System.out.println("최댓값은 : " + max);
		System.out.println("최솟값은 : " + min);

		
		

	}

}
