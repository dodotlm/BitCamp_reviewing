package HomeWork;

public class _0516_Basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
