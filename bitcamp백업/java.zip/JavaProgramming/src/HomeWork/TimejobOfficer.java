package HomeWork;

public class TimejobOfficer extends Officer{
	
	int monthpay;
	

	@Override
	public double getMonthPay(int pay, int bonus) {
		
		monthpay = pay*bonus;
		
		return monthpay;
		
	}
	
	@Override
	public void showEmployeeInfo() {
		
		System.out.println("월급은 : " + this.monthpay);
		
	}

	@Override
	public double getMonthPay(int pay) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	

}
