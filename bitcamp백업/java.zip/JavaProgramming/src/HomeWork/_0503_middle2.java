package HomeWork;

import java.util.Scanner;

public class _0503_middle2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String input = null;
		char[] test = null;
		int inputsize = 0;
		
		System.out.println("문자열을 입력해 주세요 : ");
		
		input = sc.nextLine();
		
		inputsize = input.length();
		
		for(int i =0, j=inputsize; i< inputsize; i++,j--) {
			test[j] = input.charAt(i);
		}
		
		for(int i=0; i<inputsize; i++) {
			int check =0;
			for(int j=i+1; j<inputsize; j++) {
				if(test[i] == test[j]) {
					
				}
			}
		}
		

	}

}
