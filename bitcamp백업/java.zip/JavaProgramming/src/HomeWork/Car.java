package HomeWork;

public interface Car {
	
	void speedUp();
	void speedDown();
	

}
