package HomeWork;

public class _0514_Basic01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i = 1; i <= 20; i++) {
			if(i%3 == 0 && i%4 == 0) {
				System.out.println("3과 4의 공배수 : " + i);
			}
		}
		
		Thread thread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				for(int i = 1; i <= 20; i++) {
					if(30%i == 0) {
						System.out.println("30의 약수 : " + i);
					}
					try {
						Thread.sleep(500);
					}catch(InterruptedException ie) {
						System.out.println(ie.getMessage());
					}
				}
			}
			
		});
		
		thread.start();
		

	}

}
