package HomeWork;

import java.util.Scanner;

public class _0508_basic01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String str = new String();
		
		StringBuffer strb1 = new StringBuffer();
		
		System.out.print("문자열을 입력하세요 : ");
		str = sc.nextLine();
		strb1.append(str);
		
		System.out.print("문자열을 입력하세요 : ");
		str = sc.nextLine();
		strb1.append(str);
		
		System.out.print("문자열을 입력하세요 : ");
		str = sc.nextLine();
		strb1.append(str);
		
		System.out.println(strb1);
		
		
		
		
		

	}

}
