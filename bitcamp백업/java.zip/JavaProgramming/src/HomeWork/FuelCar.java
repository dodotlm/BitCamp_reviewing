package HomeWork;

public interface FuelCar extends Car{
	
	void addFuel();

}
