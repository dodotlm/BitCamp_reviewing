package HomeWork;

public class _0502_middle {

}
