package HomeWork;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class tempadvance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		List<Integer> intList2 = 
				new ArrayList<>();
		
		for(int i = 0; i < 6; i++) {
			System.out.print("정수를 입력하세요.");
			intList2.add(sc.nextInt());
		}
		
		List<Integer> sumList = new ArrayList<>();
		
		List<Integer> cntList = new ArrayList<>();
		
		List<Integer> valueList = new ArrayList<>();
		
		for(int i = 0; i < intList2.size(); i++) {
			for(int j = i + 1; j < intList2.size(); j++) {
				if(j != i) {
					sumList.add(intList2.get(i) + intList2.get(j));
				}
			}
		}
		
		System.out.println(sumList);
		for(int i = 0; i < sumList.size(); i++) {
			int sumCnt = 1;
			
			for(int j = 0; j < sumList.size(); j++) {
				if(i != j) {
					if(sumList.get(i) == sumList.get(j)) {
						//System.out.println(sumList.get(i));
						sumCnt++;
					} 
				}
			}
			
			if(sumCnt > 0) {
				cntList.add(sumCnt);
				valueList.add(sumList.get(i));
			}
		}
		
		System.out.println(cntList);
		System.out.println(valueList);
		
		int sumCnt = 0;
		
		System.out.print("합이 유일한 합의 값: ");
		for(int i = 0; i < sumList.size(); i++) {
			if(cntList.get(i) == 1) {
				sumCnt++;
				System.out.print(valueList.get(i) + ", ");
			}
		}
		
		System.out.println("유일한 합의 개수: " + sumCnt);
		
		sc.close();
	}
	
	public static boolean isLeap(int year) {
		return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
	}

}


