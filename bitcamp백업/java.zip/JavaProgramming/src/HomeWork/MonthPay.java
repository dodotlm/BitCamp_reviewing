package HomeWork;

import java.util.Scanner;

public class MonthPay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Officer[] officer1 = new RegularOfficer[100];
		Officer[] officer2 = new TempOfficer[100];
		Officer[] officer3 = new TimejobOfficer[100];
		
		Scanner sc = new Scanner(System.in);
		
		
		
		int select = 0;
		boolean isExit = false;
		int idNumber = 0;
		int off1num = 1;
		int off2num = 1;
		int off3num = 1;
		
		while(true) {
		switch(select) {
		
			case 1 : // 정규직 
				int pay1 = 0;
				int nus1 = 0;
				System.out.print("월급은 ? : ");
				pay1 = sc.nextInt();
				System.out.print("보너스는 ? :");
				nus1 = sc.nextInt();
				officer1[off1num].getMonthPay(pay1, nus1);
				break;
			case 2 : 
				int pay2 = 0;
				System.out.print("월급은 ? : ");
				pay2 = sc.nextInt();
				officer2[off2num].getMonthPay(pay2);
				break;
			case 3 : // 계약직
				int pay3 = 0;
				int nus3 = 0;
				System.out.print("월급은 ? : ");
				pay3 = sc.nextInt();
				System.out.print("일한 날짜는 ? :");
				nus3 = sc.nextInt();
				officer3[off3num].getMonthPay(pay3, nus3);
				break;
			case 4 :
				System.out.println("모든 사원의 정보를 출력합니다.");
				for(int i =1 ; i <= officer1.length; i++) {
					System.out.println(officer1[i]);
				}
				for(int i =1 ; i <= officer2.length; i++) {
					System.out.println(officer2[i]);
				}
				for(int i =1 ; i <= officer3.length; i++) {
					System.out.println(officer3[i]);
				}
				
				break;
			case 5 :
				int temp = 0;
				System.out.println("검색할 사원의 근무형태는? >> 1: 정규직, 2: 계약직, 3. 임시직 ");
				temp = sc.nextInt();
				if(temp==1) {
					System.out.print("검색할 사원의 사번을 입력하세요 : ");
					idNumber = sc.nextInt();
					System.out.println(idNumber + " 사원의 연봉은 : ");
					officer1[idNumber].showEmployeeInfo();
					break;
				}
				if(temp==2) {
					System.out.print("검색할 사원의 사번을 입력하세요 : ");
					idNumber = sc.nextInt();
					System.out.println(idNumber + " 사원의 연봉은 : ");
					officer2[idNumber].showEmployeeInfo();
					break;
				}
				else {
					System.out.print("검색할 사원의 사번을 입력하세요 : ");
					idNumber = sc.nextInt();
					System.out.println(idNumber + " 사원의 연봉은 : ");
					officer3[idNumber].showEmployeeInfo();
					break;
				}
				
			case 6 :
				System.out.println("프로그램을 종료합니다.");
				isExit = true;
			default :
				System.out.println("잘못 입력하셨습니다.");
				
			}
		if(isExit == true) {
			break;
			}
		}
		
		
		

	}
	
	
	

}
