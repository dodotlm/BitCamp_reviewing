package HomeWork;

public class TempOfficer extends Officer{
	
	int monthpay;
	
	public double getMonthPay(int pay) {
		
		monthpay = pay/12 ;
		
		return monthpay;
		
	}
	
	@Override
	public void showEmployeeInfo() {
		
		System.out.println("월급은 : " + this.monthpay);
		
	}

	@Override
	public double getMonthPay(int pay, int bonus) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	

}
