package HomeWork;

public class HybridCar implements ElectronicCar, FuelCar{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

	@Override
	public void speedUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void speedDown() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addFuel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		
	}

}
