package HomeWork;

import java.util.Scanner;

public class _0508_Basic02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String str = new String();
		
		StringBuffer strb1 = new StringBuffer(30);

	}

}
