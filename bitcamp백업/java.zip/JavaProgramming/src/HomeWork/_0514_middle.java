package HomeWork;


public class _0514_middle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public class Coffee{
		
		
		enum CoffeeMenu{
			
			AMERICANO(2000){public int totalPrice(int optionOrder, int normalOrder) {
			return 300*optionOrder+normalOrder*this.getPrice();
			} },
			LATTE(3000){public int totalPrice(int optionOrder, int normalOrder) {
				return 500*optionOrder+normalOrder*this.getPrice();
				} },
			MOCHA(4000){public int totalPrice(int optionOrder, int normalOrder) {
				return 1000*optionOrder+normalOrder*this.getPrice();
				} },
			COLDBREW(4500){public int totalPrice(int optionOrder, int normalOrder) {
				return 200*optionOrder+normalOrder*this.getPrice();
				} };
			
			
			private final int price;
			
			
			CoffeeMenu(int price){
				this.price = price;
			}
			
			public int getPrice() {
				return this.price;
			}
			
			abstract int totalPrice(int optionOrder, int normalOrder); 
				
			
			
		}
		
		
		
		
		
	}
	
	
	

}
