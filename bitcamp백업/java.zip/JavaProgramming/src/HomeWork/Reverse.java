package HomeWork;

public class Reverse {
	
	
	public Reverse() {
		
	}
	
	
	public String reverseString(String str) {
		
		char[] rchar = null;
		int size = str.length();
		
		for(int i =0, j=size; i< size; i++,j--) {
			rchar[j] = str.charAt(i);
		}
		
		String rstrr = String.valueOf(rchar);
		
		return rstrr;
		
	}
	

}
