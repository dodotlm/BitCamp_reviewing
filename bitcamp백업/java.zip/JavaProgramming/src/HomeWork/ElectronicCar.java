package HomeWork;

public interface ElectronicCar extends Car{
	
	void charge();

}
