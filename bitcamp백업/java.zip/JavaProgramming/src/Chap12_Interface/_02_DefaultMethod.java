package Chap12_Interface;

import Chap12_Interface.device.ElectronicDevice;
import Chap12_Interface.device.LgTv;
import Chap12_Interface.device.SamsungTv;
import Chap12_Interface.device.Tv;

public class _02_DefaultMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Tv tv = new SamsungTv();
		
		tv.powerOn();
		tv.changeChannel(23);
		// 오버라이드 된 default 메소드 사용
		tv.reset();
		
		tv = new LgTv();
		// LgTv reset을 오버라이드하지 않았기 때문에
		// ElectronicDevice의 기능이 그대로 실행된다.
		
		tv.reset();
		
		ElectronicDevice.warn();
		
		// static 메소드는 상속받은 자식클래스에서는 사용이 불가능하다.
		
		// Tv.warn();  << 불가능
		
		
		
		
		

	}

}
