package Chap12_Interface.multiclass;

public interface MultiFlexStadium extends ConcertHall, Stadium {
	
	void playSportsgameOrConcert();
	
	
	
	

}
