package Chap12_Interface.multiclass;

public interface Stadium {
	
	void getSportSchedule(int month);
	int getSportsTicketPrice(int people);
	void getSupporterItem(int people);
	
	

}
