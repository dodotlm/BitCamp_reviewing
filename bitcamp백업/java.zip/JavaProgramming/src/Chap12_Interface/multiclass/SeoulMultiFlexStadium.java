package Chap12_Interface.multiclass;

// MultiFlexStadium이 Stadium과 ConcertHall의 형태도 가지고 있기 때문에
// SeoulMultiFlexStadium 클래스는
// Stadium 타입의 변수에도 사용할 수 있고 ConcertHall 타입의 변수에도 사용할 수 있고
// MultiFlexStadium 타입 변수에도 사용 할 수 있으며 SeoulMultiFlexStadium 타입 변수로도 사용할 수 있다.
// 조부모 클래스 부모 클래스 모두의 형질을 다 가지고 있기에.... 다 쓸 수 있는 거다.

// 한 클래스에서 클래스 상속도 받고 동시에 인터페이스도 상속 받을 수 있다.

public class SeoulMultiFlexStadium extends Theater implements MultiFlexStadium {

	@Override
	public void printSchedule(int month) {
		// TODO Auto-generated method stub
		System.out.println(month + "월에 예정된 경기는 총 2경기입니다.");

	}

	@Override
	public int getTicketPrice(int people) {
		// TODO Auto-generated method stub
		return people*96000;

	}

	@Override
	public void getRemainSeat() {
		
		System.out.println("남아있는 총 좌석은 125석입니다.");

	}

	@Override
	public void getSportSchedule(int month) {
		// TODO Auto-generated method stub
		System.out.println(month + "월에 예정된 경기는 총 5경기입니다.");

	}

	@Override
	public int getSportsTicketPrice(int people) {
		// TODO Auto-generated method stub
		return 7000*people;
	}

	@Override
	public void getSupporterItem(int people) {
		// TODO Auto-generated method stub
		System.out.println(people + "명의 아이템 구매 가격은"+people*15000 + "입니다");

	}

	@Override
	public void playSportsgameOrConcert() {
		// TODO Auto-generated method stub
		System.out.println("토요일은 수원대 서울의 경기가 진행되고 일요일에는 싸이의 공연이 열릴 예정입니다.");
		

	}

	@Override
	public void playMovie() {
		// TODO Auto-generated method stub
		
	}

}
