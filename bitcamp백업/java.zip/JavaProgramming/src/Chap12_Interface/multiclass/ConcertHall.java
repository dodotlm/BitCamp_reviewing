package Chap12_Interface.multiclass;

public interface ConcertHall {
	
	void printSchedule(int month);
	int getTicketPrice(int people);
	void getRemainSeat();
	
	

}
