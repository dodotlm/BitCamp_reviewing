package Chap12_Interface.multiclass;

public abstract class Theater {
	
	public abstract void playMovie();
	
	

}
