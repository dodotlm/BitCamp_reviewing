package Chap12_Interface.multiinherit;

public class Mother {
	
	public void calm() {
		System.out.println("어머니는 침착하다.");
	}

}
