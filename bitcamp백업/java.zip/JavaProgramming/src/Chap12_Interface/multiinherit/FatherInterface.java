package Chap12_Interface.multiinherit;

public interface FatherInterface {
	
	void repair();

}
