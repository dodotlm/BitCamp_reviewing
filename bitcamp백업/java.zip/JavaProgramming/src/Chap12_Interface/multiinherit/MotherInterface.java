package Chap12_Interface.multiinherit;

public interface MotherInterface {
	
	void calm();

}
