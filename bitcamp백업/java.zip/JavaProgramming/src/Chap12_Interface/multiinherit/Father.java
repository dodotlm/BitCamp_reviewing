package Chap12_Interface.multiinherit;

public class Father {
	
	public void repair() {
		System.out.println("아버지는 잘 고친다.");
	}
	
	

}
