package Chap12_Interface.device;

public interface Speaker extends ElectronicDevice {
	
	void sound();

	void changeChannel(int channel);
	
	
	
	
	
	

}
