package Chap12_Interface.device;

public interface Tv extends Display, Speaker {
	
	void changeChannel(int channel);
	
	

}
