package Chap12_Interface.device;

public interface Display extends ElectronicDevice {
	
	void showDisplay();
	
	

}
