package Chap15_Exception;

public class _01_Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] intArr = new int[3];
		
		int idx = 0;
		
		try {
		while(true) {
			System.out.println(intArr[idx++]);
			}
		}
		catch(Exception e){
			
		}
	}

}
