package Chap15_Exception;

public class _02_TryCatchFinally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] intArr = new int[3];
		String[] str = new String[3];
		
		int idx = 0;
		
		// 1. try - catch - finally
		// try 블록에 실행될 코드를 작성하고 try 블록에 작성된 코드에서 에러가 발생하면
		// catch 블록으로 이동해서 예외처리를 한다.
		// finally 블록은 예외가 발생하던지 말던지 무조건 실행되는 블록이다.
		
		// try - catch 블록은 항상 짝으로 작성해 줘야되지만
		// finally 블록은 개발자의 선택사항이다.
		
		while(true) {
			try {
				// 2. ArrayIndexOutOfBoundsException 발생
				System.out.println(intArr[idx++]);
				
				// 3. ArithmeticException 발생
				double result = 10.0/0;
				
				// 4. NullPointerException 발생
				str[0].length();
				
			}
			catch(ArrayIndexOutOfBoundsException ae) {
				//발생한 예외의 메세지 출력
				System.out.println(ae.getMessage());
				System.out.println("인덱스의 범위를 초과했습니다.");
				break;
			}
			catch(ArithmeticException ai) {
				//발생한 예외의 메세지 출력
				System.out.println(ai.getMessage());
				System.out.println("분모는 0이 될 수 없습니다.");
				break;
			}
			catch(NullPointerException np) {
				//발생한 예외의 메세지 출력
				System.out.println(np.getMessage());
				System.out.println("null에서는 속성이나 기능이 존재하지 않습니다.");
				break;
			}
			catch(Exception e) {
				//발생한 예외의 메세지 출력
				System.out.println(e.getMessage());
				System.out.println("원인미상의 오류입니다.");
				break;
			}
			finally {
				if(idx <= 3) {
					System.out.println("정상 출력");
				}
				else {
					System.out.println("예외 발생. idx를 0으로 초기화 합니다.");
					idx = 0;
				}
			}
		
		
		}
		
		

	}

}
