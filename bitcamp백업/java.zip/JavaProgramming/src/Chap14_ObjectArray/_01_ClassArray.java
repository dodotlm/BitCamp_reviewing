package Chap14_ObjectArray;

import Chap14_ObjectArray.car.Car;

public class _01_ClassArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 객체 배열 선언
		// 100개의 모든 요소가 null인 상태로 만들어지게 된다.
		
		Car[] carArr = new Car[10];
		
		// null에는 어떠한 속성도 기능도 존재하지 않는다.
		// carArr[0].CarInfo(null, null, 0, null);
		
		// 2. 객체 배열의 값
		// 객체 배열의 요소에는 항상 객체가 저장되어야 한다.
		
		carArr[0] = new Car("현대","제네시스", 5000 , "black");
		carArr[1] = new Car("kia","k9", 5000 , "white");
		carArr[2] = new Car("현대","아반떼", 3000 , "gray");
		
		// 3. 객체 배열의 사용
		// 객체 배열 요소에 하나씩 접근해서
		// 요소가 객체기 때문에 객체에 있는 메소드나 속성들을 사용한다.
		
		carArr[0].company = "porshue";
		carArr[0].model = "taikan";
		carArr[0].price = 10000;
		carArr[0].color = "red";
		
		carArr[0].CarInfo();
		
		
		int[] intArr = new int[100];
		
		intArr[0] = 1;
		
		System.out.println(intArr[0]);
		
		// 4. 일반 for문과 향상된 for문 사용가능
		
		for(int i = 0; i < carArr.length; i++) {
			if(carArr[i] != null) {
				carArr[i].CarInfo();
			}
		}
		
		for(Car c : carArr) {
			if(c != null) {
				c.CarInfo();
			}
		}
		
		

	}

}
