package Chap14_ObjectArray;

public class CarStat {
	
	public String company;
	public String model;
	public int price;
	public String color;
	
	public CarStat() {
		
	}
	
	public CarStat(String company, String model, int price, String color) {
		this.color = color;
		this.company = company;
		this.model = model;
		this.price = price;
	}
	
	
	

}
