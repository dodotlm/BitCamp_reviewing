package Chap14_ObjectArray;

import Chap14_ObjectArray.car.CarInterface;
import Chap14_ObjectArray.car.HyundaiCar;
import Chap14_ObjectArray.car.KiaCar;

public class _02_InterfaceArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 인터페이스 배열 선언
		// 모든 상태가 null인 상태로 배열이 생성된다.
		// 클래스 배열을 사용하게 되면 HyundaiCar배열과 KiaCar배열을 각각 생성해야 했지만
		// 인터페이스 배열을 사용하므로써 하나의 배열에 HyundaiCar 객체와 KiaCar 객체를 모두
		// 저장해서 사용할 수 있는 확장성이 생긴다.
		CarInterface[] carInterface = new CarInterface[100];
		
		// 2. 인터페이스 배열에 값 저장
		// 인터페이스는 객체를 만들 수 없기 때문에
		// 인터페이스 배열 요소에는 인터페이스를 상속받은 자식 객체가 저장된다.
		
		carInterface[0] = new HyundaiCar("jenesis", 5000, "black");
		carInterface[1] = new KiaCar("k9", 5000, "white");
		
		
		// 3. 인터페이스 배열의 값 사용
		// 인터페이스에 정의된 메소드만 사용할 수 있다.
		carInterface[0].carInfo();
		//carInterface[0].speedUp();
		
		// 4. for문과 향상된 for문 사용가능
		
		

	}

}
