package Chap14_ObjectArray.car;

public interface CarInterface {
	
	void carInfo();
	
	

}
