package Chap14_ObjectArray.car;

public class Car {
	
	public String company;
	public String model;
	public int price;
	public String color;
	
	
	public Car() {
		
	}
	
	public Car(String company, String model, int price, String color) {
		
		this.color = color;
		this.company = company;
		this.model = model;
		this.price = price;
		
	}
	
	public void CarInfo() {
		System.out.println("제조사 : " + this.company);
		System.out.println("색상 : " + this.color);
		System.out.println("모델 : " + this.model);
		System.out.println("가격 : " + this.price);
	}

}
