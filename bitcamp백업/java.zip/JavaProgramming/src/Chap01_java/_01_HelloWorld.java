package Chap01_java;

public class _01_HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");
		

	}

}
