package Chap02_variables;

public class _05_ShortIntLong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. short 타입의 변수 선언 및 초기화
		
		short sNum1 = 10;
		short sNum2 = 20;
		
		
		// 2. int 타입의 변수 선언 및 초기화
		
		int iNum1 = 200;
		int iNum2 = 20000000;
		
		
		// 3. long 타입의 변수 선언 및 초기화
		// 습관적으로 long 타입의 변수에 값을 저장할 때에는 값에 l.L을 붙여주는 것이 좋다.
		long lNum1 = 100L;
		long lNum2 = 100l;
		long lNum3 = 100;
		
		
		// int 범위를 초과하는 값을 longdp wjwkdgoTdmf Eodpsms l,L을 붙이지 않으면 에러가 발생하게 된다.
		
		long lNum4 = 10000000000L;
		
		

	}

}
