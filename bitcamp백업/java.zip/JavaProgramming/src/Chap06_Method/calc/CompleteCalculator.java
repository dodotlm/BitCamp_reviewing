package Chap06_Method.calc;

import java.util.Scanner;

public class CompleteCalculator {
	
	// int형 매개변수 2개를 받는 매소드 add,sub,mul.div,mod를 구현하세요.
	// 접근제어자는 모두 public으로 생성하고 div와 mod의 리턴타입만 double 나머지 메소드는 int로 저장하세요.
	// div와 mod의 두 번째 매개변수가 분모이고 분모에 0이 들어오면 0을 리턴하세요.
	
	public static int add(int a, int b) {
		// return문은 출력하는 용도로 사용되기도 하지만 종결한다는 의미로 쓰이기도 한다.
		return a+b;
	}
	
	public static int sub(int a, int b) {
		return a-b;
	}
	
	public static int mul(int a, int b) {
		return a*b;
	}
	
	public static double div(int a, int b) {
		if (b == 0) {
			return 0;
		}
		return a/b;
	}
	
	public static double mod(int a, int b) {
		if (b == 0) {
			return 0;
		}
		return a%b;
	}
	
	public static void main(String[] args) {
		
		int[] arr = new int[2];
		Scanner sc = new Scanner(System.in);
		
		System.out.print("숫자 2개를 입력해주세요 : ");
		arr[0] = sc.nextInt();
		System.out.print("하나 더 입력해 주세요 : ");
		arr[1] = sc.nextInt();
		
		System.out.println("===========================");
		System.out.println("add : " + add(arr[0],arr[1]));
		System.out.println("sub : " + sub(arr[0],arr[1]));
		System.out.println("mul : " + mul(arr[0],arr[1]));
		System.out.println("div : " + div(arr[0],arr[1]));
		System.out.println("mod : " + mod(arr[0],arr[1]));
		
		
			
		
		
		
		
	}
	
	

}
