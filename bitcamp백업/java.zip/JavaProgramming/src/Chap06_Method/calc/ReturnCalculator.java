package Chap06_Method.calc;

public class ReturnCalculator {
	// 2. 리턴타입: 메소드가 종료되고 반환하는 결과 값의 자료형을 지정
	// 2-1. 리턴타입이(결과값이) 없는 메소드는 리턴타입을 void로 지정한다.
	
	public void add () {
		System.out.println(10+20);
		
	}
	//리턴타입이 void인 메소드에서 return 구문을 사용하면 에러 발생
	
	// 2-2. 결과값이 있는 메소드는 결과값의 자료형을 리턴타입으로 지정한다.
	// 결과 값이 int인 메소드
	
	public int sub() {
		return 20-10;
	}
	
	public double div() {
		return (double)(20/10);
	}
	
	// 참조타입의 값도 리턴이 가능하다.
	
	public String createString() {
		return "Hello JAVA";
	}
	
	public int[] createArray() {
		return new int[5];
	}
	
	// 우리가 만드는 클래스들도 참조타입이기 대문에 리턴타입으로 지정이 가능하다.
	public AccessModifierCalculator createAnObject() {
		return new AccessModifierCalculator();
	}
	
	
	
	

}
