package Chap06_Method.score;

import java.util.Scanner;

public class Score {
	
	// int형 배열(정수배열)을 매개변수로 받아서 점수의 총합을 int형으로 리턴하는 매소드
	// getTotalScore를 구현하세요.
	
	public static int getTotalScore(int[] arr) {
		
		int sum = 0;
		for(int i =0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		
		return sum;
	}
	
	// 2. int형 배열(점수배열)을 매개변수 받아서 점수의 평균을 double형으로 리턴하는 매소드
	// getAverageScore를 구현하세요.
	
	public static double getAverageScore(int[] arr) {
		
		int sum = 0;
		sum = getTotalScore(arr);
		
		double avg = 0.0;
		avg = sum / arr.length;
		
		return avg;
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		
		int scoreSum = 0;
		double scoreAvg = 0.0;
		int num1 = 0;
		
		System.out.print("몇개의 숫자를 입력하실건가요 : ");
		num1 = sc.nextInt();
		
		int[] scores = new int[num1];
		
		for(int i=0; i<num1; i++) {
			System.out.print("숫자를 입력하세요 : ");
			scores[i] = sc.nextInt();
		}
		
		scoreSum = getTotalScore(scores);
		scoreAvg = getAverageScore(scores);
		
		System.out.println("합은 : " + scoreSum);
		System.out.println("평균은 : " + scoreAvg);

		
	}

}
