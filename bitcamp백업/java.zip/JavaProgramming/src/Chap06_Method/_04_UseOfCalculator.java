package Chap06_Method;

import java.util.Scanner;

import Chap06_Method.calc.CompleteCalculator;

public class _04_UseOfCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CompleteCalculator cCalc = new CompleteCalculator();
		
		int result;
		double dResult;
		
		int num1, num2;
		
		Scanner sc = new Scanner(System.in);
		System.out.print("숫자 2개를 입력해주세요 : ");
		num1 = sc.nextInt();
		System.out.print("하나 더 입력해 주세요 : ");
		num2 = sc.nextInt();
		
		
		
		
		System.out.println("add : " + cCalc.add(num1,num2));
		System.out.println("sub : " + cCalc.sub(num1,num2));
		System.out.println("mul : " + cCalc.mul(num1,num2));
		System.out.println("div : " + cCalc.div(num1,num2));
		System.out.println("mod : " + cCalc.mod(num1,num2));
		
		
		
		
		

	}

	

}
