package Chap06_Method;

public class User {

	
	private long id;
	private String username;
	private String password;
	
	public void login() {
		
	}
	
	public void join() {
		
	}
	
	public void modifyInfo() {
		
	}
	
	public void logout() {
		
	}
	
	public void deleteUser() {
		
	}

}
