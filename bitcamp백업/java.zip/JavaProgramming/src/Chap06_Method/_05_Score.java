package Chap06_Method;

import java.util.Scanner;

import Chap06_Method.score.Score;

public class _05_Score {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Score score = new Score();
		
		int studentCnt;
		
		Scanner sc = new Scanner(System.in);
		System.out.print("학생 수를 입력하세요 : ");
		studentCnt = sc.nextInt();
		
		int[] scores = new int[studentCnt];
		
		for(int i=0; i<studentCnt; i++) {
			System.out.print("점수를 입력하세요 : ");
			scores[i] = sc.nextInt();
		}
		
		int scoreSum = 0;
		double scoreAvg = 0.0;
		
		scoreSum = score.getTotalScore(scores);
		scoreAvg = score.getAverageScore(scores);
		
		System.out.println("합은 : " + scoreSum);
		System.out.println("평균은 : " + scoreAvg);
		
		
		
	}

}
