package Chap06_Method;

import Chap06_Method.calc.OverloadingCalculator;

public class _06_Overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = 10;
		int num2 = 20;
		int num3 = 30;
		double dNum1 = 40.0;
		double dNum2 = 50.0;
		
		int result;
		
		OverloadingCalculator oc = new OverloadingCalculator();
		
		
		result = oc.add(num1, num2, num3);
		System.out.println(result);
		
		result = oc.add(dNum2, num1);
		System.out.println(result);
		
		result = oc.add(num3, num2);
		System.out.println(result);
		

	}

}
