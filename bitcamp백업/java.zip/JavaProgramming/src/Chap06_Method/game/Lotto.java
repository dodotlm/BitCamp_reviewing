package Chap06_Method.game;

import java.util.Random;

public class Lotto {
	
	// 1. 1~45까지의 숫자 중 랜덤 값 7개를 저장해서 배열로 리턴하는 매소드 generateLottery를 구현하시오
	// 매개변수는 없음
	public static int[] generateLottoArray() {
		Random random = new Random(45); //0부터 44까지
		int[] lotto = new int[7];
		
		for (int i = 0; i < lotto.length; i++) {
			lotto[i] = random.nextInt(45)+1;
			
			if(isDuplicated(lotto, i)) {
				i--;
			}
			
		}
		
		return lotto;
	}
	
	// 2. 정수형 배열과 int 타입의 인덱스를 매개변수로 받아서 중복체크하는 메소드 is Duplicated를 구현하세요.
	//리턴타입 boolean => 중복이 됐으면 true 리턴, 중복이 없으면 false 리턴
	

	public static boolean isDuplicated(int[] arr, int index) {
		
		for(int i =0; i < index; i++) {
			if(arr[index] == arr[i]) {
				return true;
			}
		}
		return false;
	}
	
	
	public static void main (String[] args) {
		
		int[] Arr = new int[7];
		Arr = generateLottoArray();
		
		System.out.println("이번 주 로또 당첨 번호는 : ");
		for(int y = 0; y <=5;y++) {
			System.out.print(Arr[y] + " ");
		}
		System.out.print("\n 보너스 번호는 : "+Arr[6]);
		
		
	}
	
	
	
}







