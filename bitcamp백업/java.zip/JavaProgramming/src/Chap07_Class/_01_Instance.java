package Chap07_Class;

import Chap07_Class.car.Car;

public class _01_Instance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1. 정의한 클래스는 항상 변수로 선언해서 사용한다. (static 클래스 제외)
		// 그래서 클래스는 사용자가 직접 정의하는 자료형이라고도 한다.
		
		
		// 2. 정의한 클래스 타입의 값을 만들어주는 작업을 인스턴스화라고 한다.
		// 인스턴스화를 진행하게 되면 클래스내의 선언된 변수들과 메소드들이 메모리에 올라가고
		// 그 변수들과 메소드들을 사용할 수 있는 클래스 타입의 값이 객체로 하나 만들어지게 된다.
		
		//인스턴스화 방식 : new 생성자();
		Car car = new Car();
		// 인스턴스 객체를 생성해서 새로운 메모리 공간에 할당받기 때문에
		// car와 car1은 서로 영향을 주지 않는다.
		Car car1 = new Car();
		
		//println 메소드에 매개변수로 객체를 전달하게 되면 toString 메소드가 전달된다.
		System.out.println(car);
		
		car.company = "현대";
		car.model = "제네시스";
		car.color = "검정";
		car.price = 5000;
		
		car1.company = "삼성";
		car1.model = "SM5";
		car1.color = "회색";
		car1.price = 4000;
		
		System.out.println(car.company);
		System.out.println(car.model);
		System.out.println(car.color);
		System.out.println(car.price);
		System.out.println(car1.company);
		System.out.println(car1.model);
		System.out.println(car1.color);
		System.out.println(car1.price);
		
		
		// 4. 생성된 객체의 메소드 사용
		car.turnOn();
		car.speedUp();
		car.speedDown();
		car.turnOff();
		car.printCarInfo();
		
		car1.turnOn();
		car1.speedUp();
		car1.speedDown();
		car1.turnOff();
		car1.printCarInfo();
		
		System.out.println(car1==car); //car와 car1은 서로 다른 주소값을 바라보고 있음을 알 수 있다.
		
		
		Car car3 = generateCar(car); //그러면 얘는 returnCar와 같은 객체값을 바라보고 있게 되는건가?
		
		car3.printCarInfo();
		
		
		
		

	}
	
	//클래스는 타입의 역할도 하기 때문에 메소드의 리턴타입이나 매개변수로도 사용할 수 있다.
	public static Car generateCar(Car car) { // Car 형태의 메소드라서 
		Car returnCar = new Car();
		
		
		returnCar.company = car.company;
		returnCar.color = car.color;
		returnCar.model = car.model;
		returnCar.price = car.price;
		
		return returnCar; // Car를 지칭하는 객체가 리턴값으로 나와야 한다.
		
	}
	

}
