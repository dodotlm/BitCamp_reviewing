package Chap07_Class;

import Chap07_Class.game.Numbaseball;

public class _05_PlatBaseball {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Numbaseball bs = new Numbaseball();
		
		bs.start();

	}

}
