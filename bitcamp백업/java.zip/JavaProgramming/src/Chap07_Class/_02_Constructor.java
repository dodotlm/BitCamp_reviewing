package Chap07_Class;

import Chap07_Class.car.CarConstructor;

public class _02_Constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 기본생성자에서 company를 현대로 지정했기 때문에
		// 생성된 객체의 company는 현대로 초기화된 상태
		CarConstructor car = new CarConstructor();
		
		
		
		System.out.println(car.company);
		System.out.println(car.model);
		
		CarConstructor kiaCar = new CarConstructor("기아");
		// 이게 되는 이유는 CarConstructor 매개변수가 있는 생성자에 string 하나만 집어넣으면 되는 생성자가 있기 때문이다.
		
		System.out.println(kiaCar.company);
		System.out.println(kiaCar.color);
		
		CarConstructor blackGenesis = new CarConstructor("현대", "검정" ,"제네시스",5000);
		
		System.out.println(blackGenesis.company);
		
		
		
		
		
		

	}

}
