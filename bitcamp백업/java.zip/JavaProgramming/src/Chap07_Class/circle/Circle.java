package Chap07_Class.circle;

public class Circle {
	
	public int radious;
	public final static double PI = 3.14;
	
	
	public Circle() {
		
	}
	
	public Circle(int radious) {
		// 생성자를 호출하면 객체가 생성되는데
		// this는 생성된 객체를 받아온다.
		this.radious = radious;
	}
	
	
	public static double cirCleD(int circleBan){
		
		double circleDR = (double)(circleBan * 2 * PI);
		
		return circleDR;
	}
	
	public static double cirCleN(int circleBan){
		
		double circleNB = (double)(circleBan * circleBan * PI);
		
		return circleNB;
	}

}
