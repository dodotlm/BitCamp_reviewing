package Chap07_Class.game;

import java.util.Random;
import java.util.Scanner;

public class Numbaseball {
	// 1. 컴퓨터가 0~9까지 숫자 중 랜덤한 값 3개를 배열에 저장(중복불가능)
	// 2. 사용자가 0~9까지 숫자 세개 입력(중복불가능)
	// 3. 사용자가 입력한 숫자 중 컴퓨터가 가지고 있는 숫자와 같은 숫자면서 위치가 다르면 볼
	// 4. 사용자가 입력한 숫자 중 컴퓨터가 가지고 있는 숫자와 같은 숫자면서 위치가 같으면 스트라이크로 판정
	// com {1,2,3} user {1,3,5} ==> 1스트라이크 1볼
	// com {1,2,3} user {4,5,6} ==> 0스트라이크 0볼
	// com {1,2,3} user {1,2,3} ==> 3스트라이크 아웃 => 게임종료
	
	
	// 클래스에 필요한 필드
	
	int strike =0;
	int ball =0;
	
	int[] com  = new int[3];
	int[] user = new int[3];
	
	Scanner sc = new Scanner(System.in);
	Random random = new Random();
	
	public Numbaseball() {
		
	}
	
	public void start() {
		// com 배열에 3개의 숫자 저장
		
		for (int i=0; i < com.length; i++) {
			com[i] = random.nextInt(10);
			if(i>0) {
				for(int j =0; j <i; j++) {
					if(com[i] == com[j]) {
						i--;
						break;
					}
				}
				
			}
		}
		
		System.out.println("숫자야구를 시작합니다.");
		
		while(true) {
			
			for(int i : com) {
				System.out.println(i);
			}
			
			System.out.print("숫자 3개를 입력해 주세요 : ");
			user[0] = sc.nextInt();
			System.out.print("숫자를 두 개 더 입력해 주세요 : ");
			user[1] = sc.nextInt();
			System.out.print("숫자를 한 개 더 입력해 주세요 : ");
			user[2] = sc.nextInt();
			
//			for (int j=0; j<=1; j++) {
//				for (int k=j+1; k<=2; k++) {
//					if(this.user[j] == this.com[k]) {
//						++(this.ball);
//					}
//				}
//			}
//			for (int j=2; j>=1; j--) {
//				for (int k=0; k<=(1*j)-1; k++) {
//					if(this.user[j] == this.com[k]) {
//						++(this.ball);
//					}
//				}
//			}
//			for (int j=0; j<=2; j++) {
//				if(this.user[j] == this.com[j]) {
//					++(this.strike);
//				}
//			}
			
			for(int i=0; i<user.length; i++) {
				for(int j=0; j<this.com.length; j++) {
					if(user[i] == this.com[j]) {
						if(i == j) {
							++(strike);
						} else {
							++(ball);
						}
					}
				}
			}
			
			if(!(this.strike == 3)) {
				System.out.println(strike + "스트라이크" + ball + "볼");
			}
			else {
				System.out.println("3스트라이크 아웃");
				break;
			}
			
			this.strike = 0;
			this.ball = 0;
			
		}
		
		
		
		// 3스트라이크 아웃이 될 때 까지 사용자의 입력값 받기
	}
	

}
