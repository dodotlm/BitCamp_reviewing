package Chap07_Class;

import Chap07_Class.circle.Circle;

public class _03_UseOfCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Circle circle = new Circle(10);
		
		System.out.println(circle.radious);
		System.out.println(circle.cirCleD(10));
		System.out.println(circle.cirCleN(10));
		

	}

}
