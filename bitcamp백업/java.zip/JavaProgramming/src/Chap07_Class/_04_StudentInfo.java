package Chap07_Class;

import Chap07_Class.student.Student;

public class _04_StudentInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student std1 = new Student("마태림", 24, "소프트웨어학부");
		Student std2 = new Student("홍길동", 22, "도적학부");
		
		std1.studentInfo();
		System.out.println();
		std2.studentInfo();
		
		Student[] studentArr = new Student[3];
		
		studentArr[0] = new Student("홍길동1", 20, "수학과");
		studentArr[1] = new Student("홍길동2", 22, "화학과");
		studentArr[2] = new Student("홍길동3", 23, "미술과");
		

	}

}
