package Chap07_Class.car;

public class CarConstructor {
	
	public String company;
	public String color;
	public String model;
	public int price;
	
	public CarConstructor() {
		this.company = "현대"; // 이러면 CarConstructor 클래스를 사용하는 객체들은 모두 현대차만 만들게 된다.
	}
	
	public CarConstructor(String company) {
		this.company = company;
		
	}
	

	public CarConstructor(String company, String color, String model, int price) {
		
		// this라는 객체는 생성된 CarConstructor 객체를 지칭하는 표현
		
		this.company = company;
		this.color = color;
		this.model = model;
		this.price = price;
	}
	
	public void turnOn() {
		System.out.println("시동을 건다.");
	}
	public void turnOff() {
		System.out.println("시동을 끈다.");
	}
	public void speedUp() {
		System.out.println("속도를 높인다.");
	}
	public void speedDown() {
		System.out.println("속도를 낮춘다.");
	}
	public void printCarInfo() {
		System.out.println("제조사 : " + company);
		System.out.println("모델 : " + model);
		System.out.println("색상 : " + color);
		System.out.println("가격 : " + price);
	}
	

}
