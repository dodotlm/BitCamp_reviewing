package Chap07_Class.car;

public class Car {
	// 1. 자동차의 속성들(인스턴스 변수, 필드, 어트리뷰트...)
	public String company;
	public String color;
	public String model;
	public int price;
	
	public Car() {
		
	}
	
	public Car(String chogicompany) {
		this.company = chogicompany;
	}
	
	// 2. 자동차의 기능들(메소드, 펑션, 함수...)
	public void turnOn() {
		System.out.println("시동을 건다.");
	}
	public void turnOff() {
		System.out.println("시동을 끈다.");
	}
	public void speedUp() {
		System.out.println("속도를 높인다.");
	}
	public void speedDown() {
		System.out.println("속도를 낮춘다.");
	}
	public void printCarInfo() {
		System.out.println("제조사 : " + company);
		System.out.println("모델 : " + model);
		System.out.println("색상 : " + color);
		System.out.println("가격 : " + price);
	}
	
	
}
