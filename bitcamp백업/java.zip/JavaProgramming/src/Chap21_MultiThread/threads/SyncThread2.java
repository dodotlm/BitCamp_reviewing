package Chap21_MultiThread.threads;

public class SyncThread2 extends Thread{
	
private PrintNumberWithSync pnws;
	
	public void setPnws(PrintNumberWithSync pnws) {
		this.pnws = pnws;
	}
	
	public PrintNumberWithSync getPnws() {
		return this.pnws;
	}
	
	@Override
	public void run() {
		// 동기화 메소드 호출
		pnws.printNum2(10);
	}
	

}
