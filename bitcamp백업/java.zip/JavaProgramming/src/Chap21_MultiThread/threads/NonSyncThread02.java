package Chap21_MultiThread.threads;

public class NonSyncThread02 extends Thread{
	
	private PrintNumberWithoutSync pnws;
	
	public void setPnws() {
		this.pnws = pnws;
	}
	
	public PrintNumberWithoutSync getPnws() {
		return this.pnws;
	}
	
	@Override
	public void run() {
		pnws.printNum2(20);
	}

}
