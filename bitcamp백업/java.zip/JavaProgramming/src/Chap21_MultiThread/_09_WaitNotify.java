package Chap21_MultiThread;

import Chap21_MultiThread.threads.PrintNumWaitNotify;
import Chap21_MultiThread.threads.WaitNotifyThread01;
import Chap21_MultiThread.threads.WaitNotifyThread02;

public class _09_WaitNotify {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PrintNumWaitNotify pnwn = new PrintNumWaitNotify();
		
		WaitNotifyThread01 wt01 = new WaitNotifyThread01();
		WaitNotifyThread02 wt02 = new WaitNotifyThread02();
		
		wt01.setPnwn(pnwn);
		wt02.setPnwn(pnwn);
		
		wt01.start();
		wt02.start();
		
		

	}

}
