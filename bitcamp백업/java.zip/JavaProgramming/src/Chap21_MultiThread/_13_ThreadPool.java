package Chap21_MultiThread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import Chap21_MultiThread.threads.SumThread01;
import Chap21_MultiThread.threads.SumThread02;

public class _13_ThreadPool {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ExecutorService threadPool = Executors.newFixedThreadPool(5);
		
		threadPool.execute(new SumThread01());
		threadPool.execute(new SumThread02());
		threadPool.execute(new SumThread01());
		
		
		// 3. shutDownNow() : InterruptedException을 발생시켜서
		// 스레드 풀의 모든 스레드를 종료시킨다.
		// threadPool.shutdownNow();
		
		
		// 4. shutDown() : 메인 스레드가 종료되어도 대기큐에 있는 모든 스레드들의
		// 작업을 모두 마친 뒤에 스레드풀을 종료하는 메소드
		threadPool.shutdown();
		
		

	}

}
