package Chap21_MultiThread;

import Chap21_MultiThread.threads.DemonThread;

public class _12_DemonThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DemonThread dt = new DemonThread();
		
		// 1. setDemon(Boolean) 메소드를 통해
		// 해당 메소드를 보조 스레드로 지정
		dt.setDaemon(true);
		
		dt.start();
		
		try {
			Thread.sleep(30000);
		}catch(InterruptedException ie) {
			System.out.println(ie.getMessage());
		}
		
		// 주 스레드인 main스레드가 종료되면 보조 스레드인 dt도 종료된다.
		System.out.println("메인 스레드 종료");

	}

}
