package Chap13_NestedClass.nestedclass;

public interface Annonymous {
	
	int add(int a, int b);
	int sub(int a, int b);
	int mul(int a, int b);
	double div(int a, int b);
	int mod(int a, int b);
	
	
	

}
