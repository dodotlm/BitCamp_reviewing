package Chap13_NestedClass;

import Chap13_NestedClass.nestedclass.LocalNestedClass;

public class _02_LocalNestedClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 지역 중첩 클래스는 따로이 객체 생성이 불가능하다.
		LocalNestedClass localNestedClass = new LocalNestedClass();
		
		localNestedClass.speedUp();
		
		

	}

}
