package Chap24_DataIO;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class _09_DataInputOutputStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			// 1. DataOutputStream 객체 생성
			// DataOutputStream은 바이트 출력 스트림인 OutputStream에만 존재하는 보조 스트림
			// 기본 자료형 데이터들을 출력할 수 있는 보조 스트림이다.
			
			DataOutputStream dataOutputStream = new DataOutputStream(
					
					new FileOutputStream(
							"D:/lecture/java/JavaProgramming/src/Chap24_DataIO/DataOutputStream.txt"
							)
					);
			
			// 2. writeUTF(String 타입 매개변수) : String 타입으로 전달받은 매개변수를 출력
			dataOutputStream.writeUTF("Hyundai");
			dataOutputStream.writeUTF("jenesis");
			
			// 3. write 기본타입(기본타입의 매개변수): 기본타입으로 전달받은 매개변수를 출력
			dataOutputStream.writeInt(6000);
			dataOutputStream.writeDouble(220.5f);
			dataOutputStream.writeUTF("\n");
			
			dataOutputStream.writeUTF("Hyundai");
			dataOutputStream.writeUTF("sonata");
			dataOutputStream.writeInt(4000);
			dataOutputStream.writeDouble(200.10f);
			dataOutputStream.writeUTF("\n");
			
			dataOutputStream.writeUTF("Hyundai");
			dataOutputStream.writeUTF("avantte");
			dataOutputStream.writeInt(3000);
			dataOutputStream.writeDouble(190.07f);
			dataOutputStream.writeUTF("\n");
			
			dataOutputStream.flush();
			dataOutputStream.close();
			
			// 4. DataOutputStream 객체 생성
			// 바이트 입력 스트림인 InputStream의 보조 스트림으로 기본 자료형을 입력받을 수 있는 보조 스트림
			DataInputStream dataInputStream = new DataInputStream(
					
					new FileInputStream(
							"D:/lecture/java/JavaProgramming/src/Chap24_DataIO/DataOutputStream.txt"
							)
					);
			
			for(int i=0; i<3; i++) {
				// 5,6. readUTF는 String을 read는 int, readDouble은 double를 가져온다.
				String company = dataInputStream.readUTF();
				String model = dataInputStream.readUTF();
				int price = dataInputStream.read();
				double maxSpeed = dataInputStream.readDouble();
				System.out.println("제조사:" + company);
				System.out.println("모델:" + model);
				System.out.println("가격:" + price);
				System.out.println("최고속도:" + maxSpeed);
			}
			
			
		}catch(FileNotFoundException fe) {
			System.out.println(fe.getMessage());
		}catch(IOException ie) {
			System.out.println(ie.getMessage());
		}

	}

}
