package Chap24_DataIO;

import java.util.Scanner;

public class _08_BufferedReaderWriter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PhoneInfo phoneInfo = new PhoneInfo();
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("연락처 메뉴");
			System.out.println("1. 정보 입력");
			System.out.println("2. 모든 정보 출력");
			System.out.println("3. 이름으로 정보 검색");
			System.out.println("4. 정보 파일로 저장");
			System.out.println("5. 나가기");
			System.out.print("숫자를 입력 : ");
			int menuSelect = sc.nextInt();
			sc.nextLine();
			
			if(menuSelect == 1) {
				System.out.print("이름을 입력하세요 : ");
				String name = sc.nextLine();
				
				System.out.print("전화번호을 입력하세요 : ");
				String phoneNum = sc.nextLine();
				
				phoneInfo.insertPhoneInfo(name, phoneNum);
				
			}else if(menuSelect == 2) {
				phoneInfo.printAllPhoneInfo();
				
			}else if(menuSelect == 3) {
				
				System.out.print("검색할 사람의 이름을 입력하세요 : ");
				String searchName = sc.nextLine();
				phoneInfo.printPhoneInfo(searchName);
				
				
			}else if(menuSelect == 4) {
				phoneInfo.saveData();
			}else if(menuSelect == 5) {
				break;
			}else{
				continue;
			}
			
		}

	}

}
