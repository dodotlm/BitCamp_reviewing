package Chap24_DataIO;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class _02_ByteOutputStream02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				
				try {
					OutputStream os = new FileOutputStream(
					"D:/lecture/java/JavaProgramming/src/Chap24_DataIO/OutputStream02.txt"
							);
					
					// 1. byte 배열로 출력
					byte[] byteArr = new byte[5];
					
					for(byte i = 0; i < byteArr.length; i++) {
						byteArr[i] = i;
					}
					
					os.write(byteArr, 1, 3);
					
					// 3. 버퍼에 담긴 내용 출력하기
					os.flush();
					
					// 4. OutputStream 메모리에서 해제
					os.close();
					
					
				
				
				}catch(FileNotFoundException e) {
					e.printStackTrace();
				}
				catch(IOException ie) {
					System.out.println(ie.getMessage());
					}
				
				
				
				
				

	}

}
