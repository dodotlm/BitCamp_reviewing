package Chap17_UsefulClass;

import java.util.Calendar;

public class _01_Calendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. Calendar 객체 생성
		// Calendar 클래스의 static 메소드인 getInstance()를 사용해서 객체를 생성한다.
		// getInstance()를 통해 생성되는 객체는 Calendar를 상속받아 구현됨
		// GregorCalendar 클래스이다.
		
		Calendar calendar = Calendar.getInstance();
		
		
		// 2. 시간표시
		// Hour (0~11로 표시)
		// HOUR_OF_DAY(0~23로 표시)
		// MINUTES(0~59로 분 표시)
		// SECOND(0~59로 초 표시)
		
		System.out.println(calendar.get(Calendar.HOUR));
		System.out.println("현재 시간은 " + calendar.get(Calendar.HOUR_OF_DAY) + ":" +
				calendar.get(Calendar.MINUTE)+ ":" +
				calendar.get(Calendar.SECOND)
				);
		
		// 3. 오전 오후 표시
		// AM PM (오전이면 0, 오후면 1)
		System.out.println(calendar.get(Calendar.AM_PM) == 0 ? "오전입니다" : "오후입니다");
		
		
		// 4. 년 월 일 표시
		// YEAR(현재 년도를 4자리로 표시)
		// MONTH(0~11로 표시. 1월이 0으로 표시가 된다.)
		// WEEK_OF_YEAR (올해의 몇 번째 주인지 표시)
		// WEEK_OF_MONTH(이번달의 몇 번째 주인지 표시)
		// DAY_OF_WEEK(일요일 ~ 토요일을 1~7로 표시해준다.)
		// DATE (현재 날짜의 일자 표시)
		
		System.out.println("현재 날짜는 " + 
		
				calendar.get(Calendar.YEAR) + "-" +
				((calendar.get(Calendar.MONTH)+1) < 10 
						? "0" + (calendar.get(Calendar.MONTH)+1) : (calendar.get(Calendar.MONTH)+1))+ "-" +
				calendar.get(Calendar.DATE) 
				);
		
		
		
		System.out.println("올해의 몇 째 주 : " + calendar.get(Calendar.WEEK_OF_YEAR));
		System.out.println("올해의 몇 째 주 : " + calendar.get(Calendar.WEEK_OF_MONTH));
		
		String[] dayArr = {"", "일요일", "월요일","화요일","수요일","목요일","금요일","토요일"};
		
		System.out.println("오늘은 " + 
				dayArr[calendar.get(Calendar.DAY_OF_WEEK)]
				);
		
		
		// 5. Calendar 객체에 다른 날짜 설정하기
		// Calendar 객체의 set 메소드를 통해서 날짜를 변경할 수 있다.
		// set 메소드는 Calendar 객체가 생성된 후에 사용가능하다.
		Calendar oneDay = Calendar.getInstance();
		oneDay.set(2024,4,24,9,54,30); // 2024년 4월 24일 9시 53분 30초를 갖는 Calendar 객체
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println(DateToString(calendar));
		System.out.println(TimeToString(calendar));
		
		System.out.println(DateToString(oneDay));
		System.out.println(TimeToString(oneDay));
		
		
		
		

	}
	
	public static String DateToString(Calendar calendar) {
		// 몇년 몇월 몇일 형태의 스트링이 구현되도록 구현
		String tempdate = new String();
		tempdate = "오늘은  " + calendar.get(Calendar.YEAR)
					+ "년 "
					+ (calendar.get(Calendar.MONTH)+1)
					+ "월 "
					+ calendar.get(Calendar.DATE)
					+"일 입니다.";
		return tempdate;
	}
	
	public static String TimeToString(Calendar calendar) {
		// 몇시(0~23) 몇분 몇초 형태의 String이 구현되도록 구현
		String temphour = new String();
		temphour = "지금은 " + (calendar.get(Calendar.HOUR)+12)
					+ "시 "
					+ calendar.get(Calendar.MINUTE)
					+ "분 "
					+ calendar.get(Calendar.SECOND)
					+"초  입니다.";
		return temphour;
	}

}
