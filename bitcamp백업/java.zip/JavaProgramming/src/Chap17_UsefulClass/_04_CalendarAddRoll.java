package Chap17_UsefulClass;

import java.util.Calendar;

public class _04_CalendarAddRoll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. add 메소드: Calendar 객체에 날짜를 더해주는 메소드
		// add메소드 (더해줄 위치(Calendar.YEAR,Calendar.MONTH,Calendar.DATE), 더할 날짜)
		// add메소드는 다음 단위에도 영향을 준다.
		
		Calendar cal = Calendar.getInstance();
		
		cal.add(Calendar.DATE, 5);
		printCalendar(cal);
		
		cal.add(Calendar.DATE, 30);
		printCalendar(cal);
		
		cal.add(Calendar.YEAR, 3);
		cal.add(Calendar.MONTH, 5);
		printCalendar(cal);
		
		
		// 2. roll메소드
		// roll 메소드도 add메소드와 마찬가지로 날짜를 더해주는 메소드인데
		// roll 메소드는 다음 단위에 영향을 미치지 않는다.
		
        cal.roll(Calendar.DATE, 30); // 다음달로 넘어가지 않는다!!
        printCalendar(cal);
        
        

	}
	
	public static void printCalendar(Calendar cal) {
		System.out.println(cal.get(Calendar.YEAR) + "년" + (cal.get(Calendar.MONTH)+1) + "월" + cal.get(Calendar.DATE) + "일");
	}

}
