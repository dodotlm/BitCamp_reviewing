package Chap17_UsefulClass;

import java.util.Calendar;

public class _02_DiffOfTwoDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		
		cal2.set(2019,2,11);
		
		// gettimeInMills() : 현재 날짜 시간을 long타입 밀리세턴드로 변환해 준다.
		// 두 날짜의 차이는 = 날짜1.getTimeMills() - 날짜2.getTimeMills() (long)
		
		long diff = cal1.getTimeInMillis() - cal2.getTimeInMillis();
		
		System.out.println("cal2부터 cal1까지 " + (diff/1000) + "초가 지났습니다");
		System.out.println("cal2부터 cal1까지 " + (diff/1000/60) + "분이 지났습니다");
		System.out.println("cal2부터 cal1까지 " + (diff/1000/60/60) + "시간이 지났습니다");
		System.out.println("cal2부터 cal1까지 " + (diff/1000/60/60/24) + "일이 지났습니다");
		System.out.println("cal2부터 cal1까지 " + (diff/1000/60/60/24/30) + "달이 지났습니다");
		System.out.println("cal2부터 cal1까지 " + (diff/1000/60/60/24/365) + "년이 지났습니다");
		System.out.println("당신은 이제 고등학생이 아닙니다.... "+(diff/1000/60/60/24/365)+"년이나 지났어요...");
		
		
		// diff가 몇 년 몇일 몇시간 몇분 몇 초가 지났는지 표시하세요.
		
		System.out.println("diff는 "
				+(diff/1000/60/60/24/365)+"년 " // 5년
				+((diff/1000/60/60/24/30)-(diff/1000/60/60/24/365)*12)+"개월 " // 62달-5년
				+((diff/1000/60/60/24) - (diff/1000/60/60/24/30)*30)+"일 " // 1885일-62달
				+((diff/1000/60/60) - (diff/1000/60/60/24)*24)+"시간 " // 45263시간-1885일
				+((diff/1000/60) - (diff/1000/60/60)*60)+"분 " // 2715839분-45263시간
				
				
				
				);

	}

}
