package Chap09_Inherit.animal;

public class Tiger extends Animal{
	
	String skin;
	
	
	public Tiger() {
		
	}
	
	public Tiger(int age, String size, boolean hasWing) {
		// this.age = age;
		// this.size = size;
		// this.hasWing = hasWing;
		// 자식 클래스에서 부모 클래스를 호출 할 수 있는 super키워드라는 것이 있다.
		super(age, size, hasWing);
	}
	
	
	
	// @Override: 컴파일러가 자식클래스와 부모클래스를 비교하면서 해당 메소드가 오버라이드 됐는지 비교한다.
	// @Override 를 사용하게 되면 컴파일러에게 미리 이 메소드가 오버라이드 된 메소드라는 것을 알린다.
	// 물론 이거 오버라이드 된 메소드마다 달아줘야 함^^
	
	@Override
	public void eat() {
		// 인스턴스 메소드에서도 super라는 키워드를 사용할 수 있다.
		//super.eat();
		System.out.println("호랑이는 육식을 한다.");
		
	}
	
	@Override
	public void sleep() {
		//super.sleep();
		System.out.println("호랑이는 누워서 잔다.");
	}

}
