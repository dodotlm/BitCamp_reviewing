package Chap09_Inherit.car;

public class KiaCarInherit extends Car{
	
	public void autoPilot() {
		System.out.println(" 자율주행 한다. 부릉부릉~~ ");
	}

}
