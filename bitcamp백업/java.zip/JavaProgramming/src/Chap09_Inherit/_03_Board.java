package Chap09_Inherit;

import Chap09_Inherit.board.Board;
import Chap09_Inherit.board.FreeBoard;
import Chap09_Inherit.board.NoticeBoard;

public class _03_Board {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Board board = new FreeBoard(1, "안녕하세요", "자바 어려워요", "마태림", "20240502", "첨부파일1");
		
		board.post();
		
		board = new NoticeBoard(1, "안녕하세요", "공지사항", "관리자", "240502", false);
		
		board.post();

	}

}
