package Chap09_Inherit;

import Chap09_Inherit.car.Car;
import Chap09_Inherit.car.HyundaiCarInherit;
import Chap09_Inherit.car.KiaCarInherit;

public class _01_Inherit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 상속받은 자식클래스 객체 생성
		
		HyundaiCarInherit hCar = new HyundaiCarInherit();
		
		// 2. 부모클래스인 Car의 속성과 기능 사용
		hCar.company = "현대";
		hCar.model = "제네시스";
		hCar.color = "검정";
		hCar.price = 5000;

		hCar.carInfo();
		
		
		// 3. 자식클래스인 HyundaiCarInherit의 고유한 속성이나 기능 사용
		hCar.autoPilot();
		
		KiaCarInherit kCar = new KiaCarInherit();
		
		kCar.company = "기아";
		kCar.model = "k9";
		kCar.color = "초록";
		kCar.price = 6000;
		
		kCar.carInfo();
		kCar.autoPilot();
		
		// 코드의 재사용성을 높여줄 수 있다.
		// 코드를 줄일 수도 있어서 좋다.
		
		
		// 4. 상속은 다형성의 기초가 된다.
		// 다형성이란 다양한 형태를 띄는 성질
		// 부모클래스 타입 변수에 여러 형태의 자식 객체 담아서 사용할 수 있게 된다.
		
		Car car = new HyundaiCarInherit();
		
		
		
		//car.autoPilot();
		
		
		System.out.println(car.company);
		System.out.println(hCar.company);
		
		
		// 단 부모클래스 타입의 변수에서는 자식클래스의 고유한 변수나 메소드를 가지고 오지는 못한다.
		// ...그러면 이걸 왜 쓸까?
		
		// 부모클래스에 추상화로 진행된 메소드나 변수가 있고 그것이 자식클래스에 구현이 되어 있다면 가지고 올 수 있다!
		// 왜냐! 일단 부모클래스에 추상화가 진행되어 정의는 되었으니까!
		// 언젠간 쓸데가 있다... 기억해둬라
		
		
		
		
		
		
		
		
		
		
	}

}
