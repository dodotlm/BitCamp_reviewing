package Chap10_Polymorphism.tv;

public class LgTv extends TV{
	
	@Override
	public void powerOn() {
		System.out.println("QLED");
		// super 키워드로 생성자를 호출할 때는 항상 최상단에서 사용해야 하지만
		// 인스턴스 메소드를 사용할 때 위치는 중요하지 않다.
		
		super.powerOn();
	}
	
	@Override
	public void powerOff() {
		System.out.println("QLED");
		
		super.powerOff();
	}
	
	@Override
	
	public void operate(int channel) {
		System.out.println("QLED");
		super.operate(channel);
	}
	
	public void testTv() {
		super.powerOn();
		
		super.powerOff();
		
		super.operate(11);
		
		super.channelUp();
	}
	
	

}
