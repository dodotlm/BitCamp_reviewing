package Chap10_Polymorphism.tv;

public class SamsungTv extends TV {
	
	
	
	
	@Override
	public void powerOn() {
		System.out.println("OLED");
		super.powerOn();
	}
	
	@Override
	public void powerOff() {
		System.out.println("QLED");
		super.powerOff();
	}
	
	@Override
	public void operate(int channel) {
		System.out.println("QLED");
		super.operate(channel);
	}
	
	
	
	
	
	
}
