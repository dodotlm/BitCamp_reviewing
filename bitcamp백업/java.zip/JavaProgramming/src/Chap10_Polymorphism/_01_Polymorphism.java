package Chap10_Polymorphism;

import Chap10_Polymorphism.tv.LgTv;
import Chap10_Polymorphism.tv.SamsungTv;
import Chap10_Polymorphism.tv.TV;

public class _01_Polymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 다형성을 이용하여 TV객체 바꾸며 사용하기
		
		TV tv = new LgTv();
		
		tv.powerOn();
		
		tv = new SamsungTv();
		
		tv.powerOn();
		
		tv = new LgTv();
		
		tv.channelDown();
		
		tv = new SamsungTv();
		
		tv.channelDown();

	}

}
