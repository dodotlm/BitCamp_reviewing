package Chap10_Polymorphism;

import Chap10_Polymorphism.member.Member;

public class _02_Object {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Member member = new Member(1, "bit", "1234", "bit.com", "bitcamp");
		
		
		// println() 메소드에 객체를 매개변수로 전달하면 toString 메소드가 자동적으로 동작한다.
		// 그런데 Member 클래스에서 toString을 재정의 했기 때문에 주소값이 아니라 정의한 대로 나오게 된다...!
		System.out.println(member);

	}

}
