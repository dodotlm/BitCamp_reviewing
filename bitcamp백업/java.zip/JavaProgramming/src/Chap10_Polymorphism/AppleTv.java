package Chap10_Polymorphism;

import Chap10_Polymorphism.tv.TV;

public class AppleTv extends TV{
	
	@Override
	public void powerOn() {
		System.out.println("AppleTv");
		super.powerOn();
	}
	
	@Override
	public void powerOff() {
		System.out.println("AppleTv");
		super.powerOff();
	}
	
	// TV와 AppleTv가 다른 패키지에 속해있기 때문에
	// default 접근제어자로 선언된 operate 메소드는
	// 오버라이드 할 수 없다
	
	/*
	@Override
	public void operate(int channel) {
		
	}
	
	*/
	
	public void testTv() {
		super.powerOn();
		
		// super.operate(11); << 다른 패키지인데 default라서 안됨!
		
		super.channelUp();
	}
	
}
