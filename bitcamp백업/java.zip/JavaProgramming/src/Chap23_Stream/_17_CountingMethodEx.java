package Chap23_Stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import Chap23_Stream.car.HyundaiCar;

public class _17_CountingMethodEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 스트림처리를 통해서 가격이 최대값인 객체 하나와
		// 가격이 최솟값인 객체를 하나 찾아서 출력해라
		
		List<HyundaiCar> car = new ArrayList<>();
		
		car.add(new HyundaiCar("아반떼", 1500));
		car.add(new HyundaiCar("아반떼", 2000));
		car.add(new HyundaiCar("아반떼", 2500));
		car.add(new HyundaiCar("소나타", 3000));
		car.add(new HyundaiCar("그랜저", 3500));
		car.add(new HyundaiCar("제네시스", 4000));
		
		HyundaiCar maxPriceCar = car.stream()
                .max(Comparator.comparing(num -> num.getPrice()))
                .orElseThrow();
		
		System.out.println("요소의 최댓값 : "+maxPriceCar);
		
		HyundaiCar minPriceCar = car.stream()
                .min(Comparator.comparing(num -> num.getPrice()))
                .orElseThrow();
		
		System.out.println("요소의 최댓값 : "+minPriceCar);
		
		
		
		

	}

}
