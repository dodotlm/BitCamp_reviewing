package Chap23_Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import Chap23_Stream.card.CreditCard;

public class _04_PipeLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * List<CreditCard> 생성
		 * */
		
		List<CreditCard> cdcd = new ArrayList<>();
		
		cdcd.add(new CreditCard("카카오", "라이언카드", 1000));
		cdcd.add(new CreditCard("삼성카드", "탭탭오", 2000));
		cdcd.add(new CreditCard("신한카드", "드림카드", 3000));
		cdcd.add(new CreditCard("삼성카드", "ID카드", 5000));
		cdcd.add(new CreditCard("현대카드", "더블랙", 10000));
		cdcd.add(new CreditCard("아멕스", "블랙카드", 100000));
		
		// System.out.println(cdcd);
		
		Stream<CreditCard> cardStream = cdcd.stream();
		
		// pipe라인 없이 했을 때
		Stream<CreditCard> OverStream = cardStream.filter(card -> card.getLimit() >= 5000);
		OverStream.forEach(card -> card.cardInfo());
		
		// pipe라인 있을 때
		cdcd.stream().filter(card -> card.getLimit() >= 5000)
					.forEach(card -> card.cardInfo());

	}

}
