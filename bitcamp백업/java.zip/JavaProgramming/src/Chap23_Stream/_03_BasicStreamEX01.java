package Chap23_Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import Chap23_Stream.car.HyundaiCar;

public class _03_BasicStreamEX01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<HyundaiCar> hCarList = new ArrayList<>();
		
		hCarList.add(new HyundaiCar("아반떼", 3000));
		hCarList.add(new HyundaiCar("아반떼", 4500));
		hCarList.add(new HyundaiCar("아반떼", 2500));
		hCarList.add(new HyundaiCar("소나타", 4000));
		hCarList.add(new HyundaiCar("그랜저", 4500));
		hCarList.add(new HyundaiCar("제네시스", 5000));
		
		// 스트림을 이용해서 hCarList에 있는 아반떼만 모여있는 리스트 새로 만들기
		/*
		Stream<HyundaiCar> strStream = hCarList.stream();
		
		Stream<HyundaiCar> avanStream = strStream.filter(hCar -> hCar.getModel().equals("아반떼") );
		// str이 hyundaiCar 객체가 담겨 있는거다
		
		// mapToInt() int만 모여있는 스트림으로 변환
		IntStream priceStream = avanStream.mapToInt(av -> av.getPrice());
		
		// List<HyundaiCar> avanList = avanStream.toList();
		
		int priceSum = priceStream.sum();
		
		System.out.println(priceSum);
		
	*/
		
		// 3. 파이프라인으로 구성
		// 파이프라인으로 구성되면 최종단계 메소드의 리턴값이 리턴되기 때문에
		// 최종단계 메소드가 리턴하는 타입의 변수로 값을 받아준다.
		// 최종처리 단계가 존재하지 않으면 중간단계들은 의미가 없어지기 때문에
		// 항상 최종처리 단계를 추가한다.
		
		int priceSum = hCarList.stream() // Stream<HyundaiCar>
								// 모델명이 아반떼인 객체만 모여있는 Stream<HyundaiCar>
								.filter(hCar -> hCar.getModel().equals("아반떼"))
								// 모델명이 아반떼인 차의 가격만 모여있는 IntStream
								.mapToInt(av -> av.getPrice())
								// IntStream에 담겨있는 값의 총합
								.sum();
		
		System.out.println(priceSum);
	}

}
