package Chap18_Collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class _10_HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		List<Integer> intList2 = 
				new ArrayList<>();
		
		for(int i = 0; i < 6; i++) {
			System.out.print("정수를 입력하세요.");
			intList2.add(sc.nextInt());
		}
		// 정수 입력
		
		
		
		List<Integer> sumList = new ArrayList<>();
		
		
		Map<String, Object> intMap = new HashMap<>();
		
		for(int i = 0; i < intList2.size(); i++) {
			for(int j = i + 1; j < intList2.size(); j++) {
				if(j != i) {
					sumList.add(intList2.get(i) + intList2.get(j));
				}
			}
		}
		
		//intMap.put("여기에 합의 값", 이게 몇개 인지 int로 )
		
		
		
		for(int k = 0; k < sumList.size(); k++) {
			int cnt=1;
			for(int j=0; j < sumList.size(); j++) {
				if(sumList.get(k) == sumList.get(j)) {
					intMap.put(sumList.get(k).toString(), cnt);
					++cnt;
				}
			}	
		}
		
		
		System.out.println(sumList);
		System.out.println(intMap);
		System.out.print("합의 유일한 값 :");
		
		int cnt1 = 0;
		
		for(int k = 0; k < sumList.size(); k++) {
			int cnt2=0;
			for(int j=0; j < sumList.size(); j++) {
				if(sumList.get(k) == sumList.get(j)) {
					++cnt2;
				}
			}
			if(cnt2 == 1) {
				System.out.print(sumList.get(k) + " ");
				++cnt1;
			}
		}
		System.out.println(" 유일한 합의 갯수 : " + cnt1);
		
		
		
		
}
}
