package Chap18_Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import Chap14_ObjectArray.car.Car;

public class _06_Iterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Car> carList = new ArrayList<>();
		
		carList.add(new Car("현대" , "제네시스", 5000 , "검정"));
		carList.add(new Car("kia" , "k9", 5000 , "흰색"));
		carList.add(new Car("삼성" , "sm5", 4000 , "회색"));
		carList.add(new Car("쌍용" , "코란도", 6000 , "레드"));
		carList.add(new Car("현대" , "아반떼", 3000 , "검정"));
		
		System.out.println(carList.size());
		
		// 1. Iterator 객체 얻기
		
		Iterator<Car> carIterator = carList.iterator();
		
		while(carIterator.hasNext()) {
			Car car = carIterator.next();
			
			car.CarInfo();
			
			// iterator를 통한 데이터 삭제
			// iterator.next 메소드로 데이터를 하나 꺼내온 후에 사용가능하다.
			if(car.company.equals("현대")) {
				// iterator.next 메소드를 통해 꺼내온 데이터 List에서 삭제
				carIterator.remove();
			}
		}
		
		// 1-1 Iterator 없이 삭제하기
		
		for (int i = 0; i < carList.size(); i++) {
			if(carList.get(i).company.equals("현대")) {
				carList.remove(i--);
			}
		}
		
		// 2. ListIterator 객체 얻기
		// cursor가 0인 ListIterator 객체
		ListIterator<Car> carListIterator = carList.listIterator();
		
		// next메소드를 사용하면 iterator 객체가 다음 데이터를 가리키게 된다.
		// next로 인해서 cursor가 1인 ListIterator 객체
		carListIterator.next(); // 첫번째 데이터를 가리키게 된다.
		// cursor가 가리키고 있는 데이터 앞에 데이터를 추가한다.
		carListIterator.add(new Car("현대" , "제네시스" , 5000 , "검정"));
		
		
		while(carListIterator.hasPrevious()) {
			// previous 메소드는 iterator 객체가 이전 데이터를 가리키게 된다.
			carListIterator.previous(); // 이전 데이터를 가리키게 된다.
			
			carListIterator.add(new Car("쉐보레" , "카마로" , 5000 , "노랑"));
			
		}
		
		
		
		System.out.println(carList.size());
		
		for(Car car : carList) {
			car.CarInfo();
		}
		

	}

}
