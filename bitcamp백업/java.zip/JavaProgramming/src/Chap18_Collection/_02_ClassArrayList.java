package Chap18_Collection;

import java.util.ArrayList;
import java.util.List;

import Chap14_ObjectArray.car.Car;

public class _02_ClassArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> intList = new ArrayList<>();
		
		/*
		 * [
		 * 	{
		 * 		company: "현대"
		 * 		model : "제네시스"
		 * 		price : 5000
		 * 		color : 블랙
		 * 	},
		 * 	{
		 * 		company: "기아"
		 * 		model : "k9"
		 * 		price : 5000
		 * 		color : 흰색
		 * 	}
		 * ...............
		 * ]
		 * */
		
		List<Car> carList = new ArrayList<>();
		
		carList.add(new Car("현대", "제네시스", 5000, "검정"));
		carList.add(new Car("기아", "k9", 5000, "흰색"));
		
		System.out.println(carList);
		// List에 있는 데이터를 하나씩 꺼낼 때에는 get(int index) 메소드를 사용한다.
		for(int i = 0; i < carList.size(); i++) {
			carList.get(i).CarInfo();
		}
		
		
		
		

	}

}
