package Chap20_enum;

import Chap20_enum.enums.Season;

public class _07_SeasonEnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Season summer = Season.SUMMER;
		
		summer.printSeasonMonths();

	}

}
