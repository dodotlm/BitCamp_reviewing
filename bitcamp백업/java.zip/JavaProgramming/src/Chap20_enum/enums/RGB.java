package Chap20_enum.enums;

public enum RGB {
	
	// RED GREEN BLUE 상수선언
	// 값은 4개를 갖는다
	// 첫번째 값은 소문자 색상이름
	// 두번째 값은 빨간색 농도
	// 세번째 값은 초록색 농도
	// 네번째 값은 파란색 농도(255가 최대값)
	
	RED("red", 255, 0 , 0), GREEN("green", 0, 255 , 0), BLUE("blue", 0, 0 , 255);
	
	private String colorName;
	private int redcolor;
	private int greencolor;
	private int bluecolor;
	
	RGB(String colorName, int redcolor, int greencolor, int bluecolor){
		this.colorName = colorName;
		this.redcolor = redcolor;
		this.greencolor = greencolor;
		this.bluecolor = bluecolor;
	}
	
	public String getColorSmallName() {
		return this.colorName;
	}
	public int getRedRatio() {
		return this.redcolor;
	}
	public int getGreenRatio() {
		return this.greencolor;
	}
	public int getBlueRatio() {
		return this.bluecolor;
	}
	
	
		
	
	

}
