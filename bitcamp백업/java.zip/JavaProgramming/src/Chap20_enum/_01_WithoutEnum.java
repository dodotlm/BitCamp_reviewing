package Chap20_enum;

public class _01_WithoutEnum {
	
	// enum을 사용하지 않았을 때
	static final int JAN = 1;
	static final int FEB = 2;
	static final int MAR = 3;
	static final int APR = 4;
	static final int MAY = 5;
	static final int JUN = 6;
	static final int JUL = 7;
	static final int AUG = 8;
	static final int SEP = 9;
	static final int OCT = 10;
	static final int NOV = 11;
	static final int DEC = 12;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("JAN = " + JAN + "월");
	}
	
	

}
