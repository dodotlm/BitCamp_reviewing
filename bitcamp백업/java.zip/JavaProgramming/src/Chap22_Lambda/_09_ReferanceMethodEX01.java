package Chap22_Lambda;

import java.util.Scanner;

import Chap22_Lambda.referance.ConvertCaseString;

public class _09_ReferanceMethodEX01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. 매개변수의 타입 추론이 끝난 경우에는 static 메소드가 아니어도
		// static 메소드를 참조하는 것처럼 메소드를 참조할 수 있다.
		
		// printConvertCase(s -> s.toLowerCase());
		printConvertCase(String :: toLowerCase);
		
		

	}
	
	public static void printConvertCase(ConvertCaseString convertor) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("문자열을 입력하세요 ");
		
		String str = sc.nextLine();
		String str2 = convertor.toConvertcase(str);
		
		System.out.println("소문자로 : " + str2);
		
		
		sc.close();
		
	
	
	}

}
