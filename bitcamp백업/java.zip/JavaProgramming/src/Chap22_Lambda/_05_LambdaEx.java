package Chap22_Lambda;

import java.util.Scanner;

import Chap22_Lambda.basiclambda.BasicOfString;

public class _05_LambdaEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		findIndex((st1,st2) -> st1.contains(st2) ? st1.indexOf(st2) : -1);
		

	}
	
	// 문자열 2개를 입력받아서
	// 첫 번째 입력받은 문자열에서
	// 두 번째 입력받은 문자열이 어느 위치(인덱스)에 있는지 검사하는 메소드를 구현하세요
	// 매개변수는 함수형 인터페이스인 IndexOfString을 받습니다.
	// 검사해서 첫 번째 문자열에 두 번째 문자열이 포함되어있으면
	// 문자열1에서 문자열2의 인덱스는 8입니다. 이런 식으로
	// 검사해서 포함되어 있지 않으면
	// 감사합니다. 문자열1에서 문자열2를 찾을 수 없습니다. 라고 출력
	
	
	public static void findIndex(BasicOfString basicOfString) {
		Scanner sc = new Scanner(System.in);
		System.out.print("문자열1을 입력하세요 : ");
		String str1 = sc.nextLine();
		System.out.print("문자열2을 입력하세요 : ");
		String str2 = sc.nextLine();
		
		// findIndex라는 메소드를 호출하면서 매개변수로 전달한 람다식이 실행된다.
		int result = basicOfString.indexOf(str1, str2); // main메소드에서 지금 돌아가고 있는게 여기서 실행 중
		
		if(result == -1) {
			System.out.println("문자열1에서 문자열2를 찾을 수 없습니다.");
		}else {
			System.out.println("문자열1에서 문자열2의 인덱스는 " + result);
		}
		
	}
	

}
