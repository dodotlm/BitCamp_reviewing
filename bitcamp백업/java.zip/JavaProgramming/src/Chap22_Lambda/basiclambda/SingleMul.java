package Chap22_Lambda.basiclambda;

@FunctionalInterface

public interface SingleMul {

	// 매개변수가 하나인 함수형 인터페이스의 추상메소드
	void singleMultiply(int a);
	
	
	
}
