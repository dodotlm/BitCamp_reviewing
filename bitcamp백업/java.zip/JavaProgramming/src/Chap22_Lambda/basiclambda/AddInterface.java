package Chap22_Lambda.basiclambda;

@FunctionalInterface

public interface AddInterface {
	
	// 매개변수가 없는 함수형 인터페이스의 추상메소드
	
	void add();

}
