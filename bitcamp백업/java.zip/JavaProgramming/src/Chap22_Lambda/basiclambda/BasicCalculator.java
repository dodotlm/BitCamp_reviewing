package Chap22_Lambda.basiclambda;
@FunctionalInterface
public interface BasicCalculator {
	int calculate(int a, int b, String operator);

}
