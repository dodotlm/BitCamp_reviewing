package Chap22_Lambda.basiclambda;

@FunctionalInterface
public interface Div {
	void div(int a, int b);
}
