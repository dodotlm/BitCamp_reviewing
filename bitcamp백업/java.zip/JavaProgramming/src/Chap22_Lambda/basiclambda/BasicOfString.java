package Chap22_Lambda.basiclambda;

@FunctionalInterface
public interface BasicOfString {
	
	int indexOf(String str1, String str2);

}
