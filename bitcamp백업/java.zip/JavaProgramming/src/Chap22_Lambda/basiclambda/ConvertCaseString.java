package Chap22_Lambda.basiclambda;
@FunctionalInterface
public interface ConvertCaseString {
	
	String toConvertcase(String str);

}
