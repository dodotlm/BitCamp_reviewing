package Chap22_Lambda;

import java.util.Scanner;

import Chap22_Lambda.basiclambda.ConvertCaseString;

public class _06_LambdaEX02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printUpperCase(s1 -> s1.toLowerCase());
		printUpperCase(s2 -> s2.toUpperCase());
		
	}
	
	public static void printUpperCase(ConvertCaseString convertCaseString) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("영어단어를 입력하세요 : ");
		String str1 = sc.nextLine();
		String str2 = convertCaseString.toConvertcase(str1);
		
		System.out.println(str1 + "의 소문자대문자 반전 버전 : " + str2);
		
		
	}

}
