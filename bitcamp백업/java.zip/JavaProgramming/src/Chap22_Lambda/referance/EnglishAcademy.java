package Chap22_Lambda.referance;
@FunctionalInterface
public interface EnglishAcademy {
	
	Academy getEnglishAcademy(String subject, int studentCnt);
	
	

}
