package Chap22_Lambda.referance;
@FunctionalInterface
public interface MathAcademy {
	
	Academy getMathAcademy(String subject, int studentCnt, long lectureTime);

}
