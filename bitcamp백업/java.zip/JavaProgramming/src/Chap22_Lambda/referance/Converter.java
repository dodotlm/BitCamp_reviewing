package Chap22_Lambda.referance;
@FunctionalInterface
public interface Converter {
	
	int convert(int money, char ch);
	

}
