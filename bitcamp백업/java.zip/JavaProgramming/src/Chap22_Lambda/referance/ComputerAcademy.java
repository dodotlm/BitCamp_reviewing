package Chap22_Lambda.referance;
@FunctionalInterface
public interface ComputerAcademy {
	
	Academy getComputerAcademy();
	

}
