package Chap22_Lambda.referance;
@FunctionalInterface
public interface ConvertCaseString {
	
	String toConvertcase(String str);

}
