package Chap22_Lambda;

import java.util.Scanner;

import Chap22_Lambda.basiclambda.BasicCalculator;

public class _07_LambdaEX03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int result = calc((n1, n2, opr) -> {
		if(opr.equals("+")){
			return n1+n2;
		}else if(opr.equals("-")) {
			return n1-n2;
		}else if(opr.equals("*")) {
			return n1*n2;
		}else if(opr.equals("/")) {
			return n1/n2;
		}else{
			return n1%n2;
		}
			}
				);
		
		System.out.println(result);
		

	}
	
	public static int calc(BasicCalculator basicCalculator) {
		// 정수 두 개 입력 받고
		
		Scanner sc = new Scanner(System.in);
		System.out.print(" 정수 1개 입력 : ");
		int num1 = sc.nextInt();
		System.out.print(" 정수 1개 입력 : ");
		int num2 = sc.nextInt();
		System.out.print(" operator 1개 입력 : ");
		sc.nextLine();
		String op = sc.nextLine();
		
		
		
		return basicCalculator.calculate(num1, num2, op);
		
		
	}

}
