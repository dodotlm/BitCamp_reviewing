package Practice;

import Chap07_Class.student.Student;

public class PrintStudentInfo {
	/*
	public void searchStudent(int sno, Student[] stArr) {
		for(int i =0; i < stArr.length; i++) {
			if(stArr[i].getSno() == sno) {
				stArr[i].printInfo();
				break;
			}
		}
	}
	
	
	
	// 모든 학생 정보 출력하는 메소드
	public void printAllStudentInfo(int index, Student[] stArr) {
		for(int i = 0; i <index; i++) {
			stArr[i].printInfo();
		}
	}
*/
}
