package Practice;

import java.util.Scanner;

import Chap07_Class.student.Student;

public class InputSubjectScore {
	
	// 과목과 기말고사를 입력하는 메소드
	/* public void inputSubjectScoreInfo(Scanner sc, Student[] strArr) {
		System.out.println("학생의 학번 입력해주세요.");
		int sno = sc.nextInt();
		
		for(int i=0; i < .length; i++) {
			if(stArr[i].getSno() == sno) {
				System.out.println(strArr[i].getName() + "학생이 수강한 과목의 갯수를 입력하세요");
				int cnt = sc.nextInt();
				sc.nextInt();
				
				strArr[i].initSubScore(cnt);
			}
			
			for(int j = 0; j < cnt; j++) {
				System.out.println("과목을 입력하세요");
				String subject = sc.nextLine();
				System.out.println("기말고사 점수를 입력하세요");
				int score = sc.nextInt();
				
				strArr[i].saveInfo(i,subject, score);
			}
			
			stCnt++;
			
			break;
			
		}
		
		if(stCnt == 0) {
			System.out.println("기본정보가 입력되지 않은 학생들 입니다.");
		}
		
		sc.close();
		
		
		
	}
*/
}
