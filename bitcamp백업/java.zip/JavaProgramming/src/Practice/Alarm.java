package Practice;

import java.util.Scanner;

public class Alarm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);

        // 띄어쓰기로 구분된 문자열 입력 받기
        String inputLine = sc.nextLine();

        // 입력된 문자열을 공백(" ")을 기준으로 문자열 배열로 분할
        String[] tokens = inputLine.split(" ");

        // 정수형 배열 생성
        int[] numbers = new int[tokens.length];

        // 문자열 배열을 정수형 배열로 변환
        for (int i = 0; i < tokens.length; i++) {
            numbers[i] = Integer.parseInt(tokens[i]);
        }
        
        // 정수형 배열로 잘 바뀌었나 확인
        for (int num : numbers) {
            System.out.print(num + " ");
        }

        sc.close();
        
        
		
		
		

	}

}
