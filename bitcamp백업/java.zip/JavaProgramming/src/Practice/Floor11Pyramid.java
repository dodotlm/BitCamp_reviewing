package Practice;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Floor11Pyramid {

	private static int[] s1 = {1,2,3,4,5};
	private static int[] s2 = {1,2,3,1,2,3,2,1,2,3};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
			// s1 = {1,2,3,4,5}
			// s2 = {1,2,3,1,2,3,2,1,2,3}
			Set<Integer> set = new HashSet<>();

			for(int num : s2 ){ // s2에 있는 정수들을 배열 끝까지 다 돌리기
			  set.add(num); // Set의 객체인 set에 배열의 값들을 다 담는다. 단 중복되지 않도록!!!
			}
			// set = {1,2,3}
			 Arrays.stream(s1) // stream<integer> = {1,2,3,4,5}
			 // filter : 조건이 true인 값만 모아서 stream<Integer>로 만든다.
			        .filter(num -> !set.contains(num))
			        .toArray();
			 
			 Arrays.stream(s2) // stream<integer> = {1,2,3,4,5}
			 // filter : 조건이 true인 값만 모아서 stream<Integer>로 만든다.
			        .filter(num -> !set.contains(num))
			        .toArray();
			
			 for(int i=0; i<s1.length; i++ ) {
				 System.out.print(s1[i]);
			 }
			 
			 System.out.println();
			 for(int i=0; i<s2.length; i++ ) {
				 System.out.print(s2[i]);
			 }
			 
			 
	}
}