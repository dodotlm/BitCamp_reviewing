package Chap19_Generic;

import Chap19_Generic.board.FreeBoard;
import Chap19_Generic.board.boardFile;

public class _03_GenericClassBoard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boardFile<FreeBoard> freeBoardFile = new boardFile<>();
		
		freeBoardFile.setType(new FreeBoard(1, "자유게시판 제목"));
		freeBoardFile.setFileNm("자유게시판 첨부파일1");
		freeBoardFile.setBoardNo(1);
		
		System.out.println(freeBoardFile);

	}

}
