package Chap19_Generic;

import Chap19_Generic.ramyun.Danmuji;
import Chap19_Generic.ramyun.Kimchi;
import Chap19_Generic.ramyun.LimitedRamyun01;
import Chap19_Generic.ramyun.PaKimchi;

public class _05_LimitedGenericClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LimitedRamyun01<Kimchi> kimchiRamyun = new LimitedRamyun01<>();
		// LimitedRamyun01 클래스에 제한을 걸어둔 Kimchi 부모클래스랑 그 밑에 있는 자식클래스까지 사용가능
		
		LimitedRamyun01<PaKimchi> pakimchiRamyun = new LimitedRamyun01<>();
		
		// LimitedRamyun01<Danmuji> danmujiiRamyun = new LimitedRamyun01<>();
		// Kimchi를 상속받지 않은 Danmuji는 서브클래스의 타입으로 지정할 수 없다.
		
		

	}

}
