package Chap19_Generic.board;

public class NoticeBoard {
	private int noticeboardNo;
	private String noticeBoardTitle;
	
	public NoticeBoard() {
		
	}
	
	public NoticeBoard(int noticeboardNo, String noticeBoardTitle) {
		this.noticeboardNo = noticeboardNo;
		this.noticeBoardTitle = noticeBoardTitle;
	}
	

	public int getNoticeboardNo() {
		return noticeboardNo;
	}

	public void setNoticeboardNo(int noticeboardNo) {
		this.noticeboardNo = noticeboardNo;
	}

	public String getNoticeBoardTitle() {
		return noticeBoardTitle;
	}

	public void setNoticeBoardTitle(String noticeBoardTitle) {
		this.noticeBoardTitle = noticeBoardTitle;
	}

	@Override
	public String toString() {
		return "NoticeBoard [noticeboardNo=" + noticeboardNo + ", noticeBoardTitle=" + noticeBoardTitle + "]";
	}
	

}
