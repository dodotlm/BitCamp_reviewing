package Chap19_Generic.board;

public class FreeBoard {
	
	private int freeboardNo;
	private String freeBoardTitle;
	
	public FreeBoard() {
		
	}
	
	public int getFreeboardNo() {
		return freeboardNo;
	}

	public void setFreeboardNo(int freeboardNo) {
		this.freeboardNo = freeboardNo;
	}

	public String getFreeBoardTitle() {
		return freeBoardTitle;
	}

	public void setFreeBoardTitle(String freeBoardTitle) {
		this.freeBoardTitle = freeBoardTitle;
	}

	public FreeBoard(int freeboardNo, String freeBoardTitle) {
		this.freeboardNo = freeboardNo;
		this.freeBoardTitle = freeBoardTitle;
		
	}

	@Override
	public String toString() {
		return "FreeBoard [freeboardNo=" + freeboardNo + ", freeBoardTitle=" + freeBoardTitle + "]";
	}
	
	
}
