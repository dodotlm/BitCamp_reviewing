package Chap19_Generic;

import java.util.ArrayList;
import java.util.List;

import javax.imageio.plugins.jpeg.JPEGImageReadParam;

import Chap19_Generic.ramyun.Danmuji;
import Chap19_Generic.ramyun.Kimchi;
import Chap19_Generic.ramyun.Ramyun;

public class _02_Generics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 제네릭 클래스 변수를 선언할 때 제네릭 클래스의 서브클래스 타입을 지정한다.
		
		Ramyun<Danmuji> ramyun = new Ramyun<>();
		
		ramyun.setT(new Danmuji());
		
		System.out.println(ramyun.getT());
		
		List<Danmuji> danmujiList = new ArrayList<>();
		
		danmujiList.add(new Danmuji());
		danmujiList.add(new Danmuji("White"));
		
		ramyun.settList(danmujiList);
		
		for(Danmuji danmuji : danmujiList) {
			System.out.println(danmuji);
		}
		
		Ramyun<Kimchi> kimchiRamyun = new Ramyun<>();
		
		kimchiRamyun.setT(new Kimchi());
		
		System.out.println(kimchiRamyun.getT());
		
		

	}

}
