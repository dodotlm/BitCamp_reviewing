package Chap19_Generic.ramyun;

public class MulKimchi extends Kimchi{
	
	public MulKimchi() {
		super("white");
	}
	
	public MulKimchi(String color) {
		super(color);
	}

	
	

}
