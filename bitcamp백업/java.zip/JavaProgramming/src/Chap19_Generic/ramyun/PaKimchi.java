package Chap19_Generic.ramyun;

public class PaKimchi extends Kimchi{
	
	public PaKimchi() {
		super("green");
	}
	
	public PaKimchi(String color) {
		super(color);
	}
	
	

}
