package Chap11_Abstraction;

import Chap11_Abstraction.board.Board;
import Chap11_Abstraction.board.FreeBoard;
import Chap11_Abstraction.board.NoticeBoard;

public class _02_AbstractionBoard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Board board = new FreeBoard(1, "자바 프로그래밍", "자바의 추상화에 대해서 알아보자", "마태림", "0502", "\'이것이 자바다\' ");
		
		
		board.post();
		board.modify();
		board.delete();
		
		System.out.println("=============================================================================");
		
		board = new NoticeBoard(2, "오늘의 공지사항", "과제 다 할 때가지 집에 못 감", "마태림", "0502", false);
		
		board.post();
		board.modify();
		board.delete();
		
		
		

	}

}
