package Chap11_Abstraction;

import Chap11_Abstraction.tv.LgTv;
import Chap11_Abstraction.tv.SamsungTv;
import Chap11_Abstraction.tv.TV;

public class _03_AbstractionTv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TV tv = new SamsungTv();
		
		
		tv.operate(5);
		tv.channelUp();
		tv.channelDown();
		tv.moveTo(10);
		
		tv = new LgTv();
		
		tv.operate(9);
		tv.channelUp();
		tv.channelDown();
		tv.moveTo(11);
		
		

	}

}
