package Chap11_Abstraction.tv;

public class SamsungTv extends TV {
	
	
	
	
	@Override
	public void powerOn() {
		System.out.println("SAMSUNG QLED");
		// super 키워드로 생성자를 호출할 때는 항상 최상단에서 사용해야 하지만
		// 인스턴스 메소드를 사용할 때 위치는 중요하지 않다.
		
		System.out.println("TV의 전원을 킵니다");
	}
	
	@Override
	public void powerOff() {
		System.out.println("SAMSUNG QLED");
		System.out.println("TV의 전원을 끕니다.");
	}
	
	@Override
	
	public void operate(int channel) {
		System.out.println("SAMSUNG QLED");
		
		lastChannel = channel;
		moveTo(channel);
	}
	
	public void testTv() {
		
		powerOn();
		powerOff();
		operate(lastChannel);
		channelUp();
		channelDown();
		
	}

	@Override
	public void moveTo(int channel) {
		// TODO Auto-generated method stub
		System.out.println(channel + "로 이동합니다.");
		
	}

	@Override
	public void channelUp() {
		// TODO Auto-generated method stub
		lastChannel++;
		
	}

	@Override
	public void channelDown() {
		// TODO Auto-generated method stub
		lastChannel--;
		
	}
	
	
	
	
	
	
}
