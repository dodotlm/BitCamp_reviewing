package Chap11_Abstraction.tv;

public abstract class TV {
	
	public int lastChannel;
	
	public TV() {
		lastChannel = 1;
	}
	
	
	
	
	public abstract void powerOn();
	
	public abstract void powerOff();
	
	public abstract void operate (int channel);
	
	public abstract void moveTo(int channel);
	
	public abstract void channelUp();
	
	public abstract void channelDown();
	
	

}
