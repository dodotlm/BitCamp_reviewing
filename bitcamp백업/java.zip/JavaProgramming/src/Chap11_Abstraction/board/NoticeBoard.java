package Chap11_Abstraction.board;

public class NoticeBoard extends Board{
	
	boolean isAdmin = false;

	public NoticeBoard(long id, String title, String content, String writer, String creDate, boolean isAdmin) {
		super(id, title, content, writer, creDate);
		this.isAdmin = isAdmin;
	}
	
	
	public void post() {
		if(this.isAdmin) {
			System.out.println("관리자가 공지사항을 업로드 합니다.");
		}
		else {
			System.out.println("공지사항은 관리자만 등록할 수 있습니다.");
		}
	}
	
	@Override
	public void modify() {
		System.out.println("게시물을 수정합니다.");
		// TODO Auto-generated method stub
		
	}


	@Override
	public void delete() {
		System.out.println("게시물을 삭제합니다.");
		// TODO Auto-generated method stub
		
	}
	
	
	

}
