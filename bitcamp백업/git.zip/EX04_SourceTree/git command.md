# 깃 명령어
1. git init - 로컬 저장소 생성
2. git add - 새로운 버전에 추가할 파일 지정
3. git commit - 새로운 버전 생성
4. git remote add origin - 원격저장소와의 연결
5. git push - 원격 저장소에 코드와 버전 업로드
6. git clone - 원격저장소에 있는 내용 다운
7. git pull - 원격저장소에 업데이트 된 내용 다운