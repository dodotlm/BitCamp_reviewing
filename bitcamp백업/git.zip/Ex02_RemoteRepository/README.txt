Git Example 02-Remote Repository-modify
  git init - 로컬 저장소 생성
  git add - 새로운 버전에 추가할 파일 지정
  git commit - 새로운 버전 만들기(현재 내용 저장)
  git remote add origin - 원격 저장소와 로컬 저장소 연결
  git push - 원격 저장소에 코드와 버전 업로드
  git clone - 원격 저장소의 내용 다운로드