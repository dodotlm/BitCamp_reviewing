# 1. checkout
1. hceckout은 HEAD라는 포인터를 다른 브랜치나 이전 커밋으로 올기는 명령어
2. sourcetree에서는 좌측 사이드바의 브랜치 항목에서 해당 브랜치를 더블 클릭하면 자동으로 checkout된다.