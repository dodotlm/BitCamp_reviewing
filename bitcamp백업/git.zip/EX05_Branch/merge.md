# 1. merge
1. merge는 branch끼리 코드를 병합하는 과정 또는 명령어.